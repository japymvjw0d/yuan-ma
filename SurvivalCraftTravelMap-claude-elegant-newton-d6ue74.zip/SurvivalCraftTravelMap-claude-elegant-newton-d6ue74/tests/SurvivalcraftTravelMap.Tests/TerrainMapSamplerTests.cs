using System.Text;
using System.Text.Json;
using SurvivalcraftTravelMap.Map;
using Xunit;

namespace SurvivalcraftTravelMap.Tests;

public sealed class TerrainMapSamplerTests
{
    private static readonly int[] TransparentTopContents = [28, 99, 174, 25];
    private static readonly int[] WaterVariantContents = [226, 229, 232, 233];

    [Theory]
    [InlineData(TerrainChunkCoordinate.PixelCount - 1)]
    [InlineData(TerrainChunkCoordinate.PixelCount + 1)]
    public void Try_sample_chunk_requires_exactly_one_chunk_of_destination_space(int length)
    {
        var source = new FakeTerrainMapSource();
        var sampler = new TerrainMapSampler(source, CreatePixelData());

        Assert.Throws<ArgumentException>(() =>
            sampler.TrySampleChunk(new TerrainChunkCoordinate(0, 0), new Rgba32[length]));
        Assert.Equal(0, source.ChunkReadinessChecks);
        Assert.Empty(source.SampledColumns);
        Assert.Empty(source.ContentCalls);
    }

    [Fact]
    public void Try_sample_chunk_checks_readiness_once_and_does_not_read_an_unready_chunk()
    {
        var source = new FakeTerrainMapSource(isReady: false);
        var sampler = new TerrainMapSampler(source, CreatePixelData());
        var destination = Enumerable.Repeat(
            new Rgba32(20, 30, 40, 50),
            TerrainChunkCoordinate.PixelCount).ToArray();
        var chunk = new TerrainChunkCoordinate(7, -9);

        var sampled = sampler.TrySampleChunk(chunk, destination);

        Assert.False(sampled);
        Assert.Equal(1, source.ChunkReadinessChecks);
        Assert.Equal([chunk], source.RequestedChunks);
        Assert.Equal(0, source.ColumnReadinessChecks);
        Assert.Empty(source.SampledColumns);
        Assert.Empty(source.ContentCalls);
        Assert.All(destination, color => Assert.Equal(new Rgba32(20, 30, 40, 50), color));
    }

    [Fact]
    public void Try_sample_chunk_samples_all_negative_origin_columns_in_z_major_order()
    {
        var source = new FakeTerrainMapSource(topHeight: 72, defaultContent: 1);
        var sampler = new TerrainMapSampler(source, CreatePixelData(overrides: new Dictionary<int, BlockPixelData>
        {
            [1] = Pixel(1, 10, 20, 30),
        }));
        var destination = new Rgba32[TerrainChunkCoordinate.PixelCount];
        var chunk = new TerrainChunkCoordinate(-2, -3);

        var sampled = sampler.TrySampleChunk(chunk, destination);

        Assert.True(sampled);
        Assert.Equal(1, source.ChunkReadinessChecks);
        Assert.Equal([chunk], source.RequestedChunks);
        Assert.Equal(0, source.ColumnReadinessChecks);
        Assert.Equal(
            from localZ in Enumerable.Range(0, TerrainChunkCoordinate.Size)
            from localX in Enumerable.Range(0, TerrainChunkCoordinate.Size)
            select (chunk.OriginX + localX, chunk.OriginZ + localZ),
            source.SampledColumns);
        Assert.Equal(TerrainChunkCoordinate.PixelCount, source.ContentCalls.Count);
        Assert.All(destination, color => Assert.Equal(new Rgba32(10, 20, 30, 255), color));
    }

    [Fact]
    public void Try_sample_chunk_calculates_reference_height_shading_for_sloped_ground()
    {
        var source = new FakeTerrainMapSource(topHeight: 64, defaultContent: 1);
        for (var z = 0; z < TerrainChunkCoordinate.Size; z++)
        {
            for (var x = 0; x < TerrainChunkCoordinate.Size; x++)
            {
                source.SetTopHeight(x, z, 60 + x + z);
            }
        }

        var sampler = new TerrainMapSampler(source, CreatePixelData());
        var colors = new Rgba32[TerrainChunkCoordinate.PixelCount];
        var heightShades = new byte[TerrainChunkCoordinate.PixelCount];

        var sampled = sampler.TrySampleChunk(new TerrainChunkCoordinate(0, 0), colors, heightShades);

        Assert.True(sampled);
        Assert.DoesNotContain(TerrainHeightShading.Unknown, heightShades);
        Assert.Contains(heightShades, shade => shade > TerrainHeightShading.Neutral);
    }

    [Fact]
    public void Cross_plants_keep_neutral_shading_on_sloped_ground()
    {
        var source = new FakeTerrainMapSource(topHeight: 64, defaultContent: 19);
        source.CrossPlantContents.Add(19);
        for (var z = 0; z < TerrainChunkCoordinate.Size; z++)
        {
            for (var x = 0; x < TerrainChunkCoordinate.Size; x++)
            {
                source.SetTopHeight(x, z, 60 + x + z);
            }
        }

        var sampler = new TerrainMapSampler(source, CreatePixelData(overrides: new Dictionary<int, BlockPixelData>
        {
            [19] = Pixel(19, 171, 171, 171, changesWithEnvironment: true),
        }));
        var colors = new Rgba32[TerrainChunkCoordinate.PixelCount];
        var heightShades = new byte[TerrainChunkCoordinate.PixelCount];

        var sampled = sampler.TrySampleChunk(new TerrainChunkCoordinate(0, 0), colors, heightShades);

        Assert.True(sampled);
        Assert.All(heightShades, shade => Assert.Equal(TerrainHeightShading.Neutral, shade));
    }

    [Fact]
    public void Chunk_commit_seam_keeps_existing_tile_byte_identical_when_mid_chunk_sample_is_transparent()
    {
        var source = new FakeTerrainMapSource(topHeight: 64, defaultContent: 1);
        source.SetContent(5, 64, 6, 0);
        var sampler = new TerrainMapSampler(source, CreatePixelData(overrides: new Dictionary<int, BlockPixelData>
        {
            [1] = Pixel(1, 10, 20, 30),
        }));
        var tile = CreateSeededTile();
        var before = CaptureTileState(tile);
        var untouched = new Rgba32(200, 201, 202, 203);
        var staging = Enumerable.Repeat(untouched, TerrainChunkCoordinate.PixelCount).ToArray();

        var committed = TrySampleChunkAndCommit(
            sampler,
            new TerrainChunkCoordinate(0, 0),
            tile,
            staging);

        Assert.False(committed);
        Assert.Equal(1, source.ChunkReadinessChecks);
        Assert.Equal(0, source.ColumnReadinessChecks);
        Assert.Equal(new Rgba32(10, 20, 30, 255), staging[0]);
        Assert.NotEqual(untouched, staging[0]);
        Assert.Equal(0, staging[(6 * TerrainChunkCoordinate.Size) + 5].A);
        AssertTileStateUnchanged(before, tile);
    }

    [Fact]
    public void Chunk_commit_seam_keeps_existing_tile_byte_identical_when_mid_chunk_sample_throws()
    {
        var sentinel = new InvalidOperationException("mid-chunk sentinel");
        var source = new FakeTerrainMapSource(topHeight: 64, defaultContent: 1);
        source.ThrowFromTopHeightAt(4, 5, sentinel);
        var sampler = new TerrainMapSampler(source, CreatePixelData(overrides: new Dictionary<int, BlockPixelData>
        {
            [1] = Pixel(1, 10, 20, 30),
        }));
        var tile = CreateSeededTile();
        var before = CaptureTileState(tile);
        var untouched = new Rgba32(200, 201, 202, 203);
        var staging = Enumerable.Repeat(untouched, TerrainChunkCoordinate.PixelCount).ToArray();

        var exception = Assert.Throws<InvalidOperationException>(() =>
            TrySampleChunkAndCommit(
                sampler,
                new TerrainChunkCoordinate(0, 0),
                tile,
                staging));

        Assert.Same(sentinel, exception);
        Assert.Equal(new Rgba32(10, 20, 30, 255), staging[0]);
        Assert.NotEqual(untouched, staging[0]);
        Assert.Equal(untouched, staging[(5 * TerrainChunkCoordinate.Size) + 4]);
        AssertTileStateUnchanged(before, tile);
    }

    [Fact]
    public void Chunk_commit_seam_sets_one_tile_region_after_complete_sample_succeeds()
    {
        var source = new FakeTerrainMapSource(topHeight: 64, defaultContent: 1);
        var sampler = new TerrainMapSampler(source, CreatePixelData(overrides: new Dictionary<int, BlockPixelData>
        {
            [1] = Pixel(1, 10, 20, 30),
        }));
        var tile = CreateSeededTile();
        var before = CaptureTileState(tile);
        var staging = new Rgba32[TerrainChunkCoordinate.PixelCount];

        var committed = TrySampleChunkAndCommit(
            sampler,
            new TerrainChunkCoordinate(0, 0),
            tile,
            staging);

        var after = CaptureTileState(tile);
        Assert.True(committed);
        Assert.Equal(before.Version + 1, after.Version);
        Assert.False(before.Explored.AsSpan().SequenceEqual(after.Explored));
        Assert.False(before.Colors.AsSpan().SequenceEqual(after.Colors));
        Assert.True(tile.TryGetPixel(16, 32, out var color));
        Assert.Equal(new Rgba32(10, 20, 30, 255), color);
    }

    [Fact]
    public void Try_sample_rejects_a_transparent_air_pixel()
    {
        var source = new FakeTerrainMapSource(topHeight: 0, defaultContent: 0);
        var sampler = new TerrainMapSampler(source, CreatePixelData(overrides: new Dictionary<int, BlockPixelData>
        {
            [0] = Pixel(0, 0, 0, 0, alpha: 0),
        }));

        var sampled = sampler.TrySample(12, -8, out var color);

        Assert.False(sampled);
        Assert.Equal(default, color);
    }

    [Fact]
    public void Try_sample_does_not_read_an_unready_terrain_column()
    {
        var source = new FakeTerrainMapSource(defaultContent: 1, isReady: false);
        var sampler = new TerrainMapSampler(source, CreatePixelData());

        var sampled = sampler.TrySample(12, -8, out var color);

        Assert.False(sampled);
        Assert.Equal(default, color);
        Assert.Empty(source.SampledColumns);
        Assert.Empty(source.ContentCalls);
    }

    [Theory]
    [MemberData(nameof(TransparentTopCases))]
    public void Transparent_top_content_reveals_the_block_one_cell_below(int transparentContent)
    {
        var source = new FakeTerrainMapSource(topHeight: 70, defaultContent: 1);
        source.SetContent(12, 70, -8, transparentContent);
        source.SetContent(12, 69, -8, 2);
        var sampler = new TerrainMapSampler(source, CreatePixelData(overrides: new Dictionary<int, BlockPixelData>
        {
            [1] = Pixel(1, 10, 20, 30),
            [2] = Pixel(2, 40, 50, 60),
        }));

        var color = sampler.Sample(12, -8);

        Assert.Equal(new Rgba32(40, 50, 60, 255), color);
        Assert.Equal([(12, 70, -8), (12, 69, -8)], source.ContentCalls);
    }

    [Theory]
    [MemberData(nameof(WaterVariantCases))]
    public void Water_variants_use_the_base_water_color(int waterContent)
    {
        var source = new FakeTerrainMapSource(topHeight: 64, defaultContent: waterContent);
        var sampler = new TerrainMapSampler(source, CreatePixelData(overrides: new Dictionary<int, BlockPixelData>
        {
            [18] = Pixel(18, 4, 80, 120),
            [waterContent] = Pixel(waterContent, 240, 10, 10),
        }));

        var color = sampler.Sample(3, 5);

        Assert.Equal(new Rgba32(4, 80, 120, 255), color);
    }

    [Theory]
    [InlineData(8, 151, 184, 195)]
    [InlineData(12, 96, 161, 123)]
    [InlineData(13, 76, 181, 96)]
    [InlineData(14, 96, 161, 155)]
    [InlineData(18, 0, 0, 120)]
    [InlineData(19, 151, 184, 195)]
    [InlineData(225, 90, 141, 165)]
    [InlineData(256, 146, 191, 176)]
    public void Environment_sensitive_contents_use_their_daytime_palette(
        int content,
        byte expectedR,
        byte expectedG,
        byte expectedB)
    {
        var source = new FakeTerrainMapSource(
            topHeight: 64,
            defaultContent: content,
            seasonalTemperature: 0,
            seasonalHumidity: 4);
        var sampler = new TerrainMapSampler(source, CreatePixelData(overrides: new Dictionary<int, BlockPixelData>
        {
            [content] = Pixel(content, 255, 255, 255, changesWithEnvironment: true),
        }));

        var color = sampler.Sample(-2, 9);

        Assert.Equal(new Rgba32(expectedR, expectedG, expectedB, 255), color);
        Assert.Equal([(-2, 9)], source.TemperatureCalls);
        Assert.Equal([(-2, 9)], source.HumidityCalls);
    }

    [Fact]
    public void Environmental_palette_multiplies_the_configured_base_color_and_adjusts_temperature_for_height()
    {
        var source = new FakeTerrainMapSource(
            topHeight: 54,
            defaultContent: 8,
            seasonalTemperature: 0,
            seasonalHumidity: 4);
        var sampler = new TerrainMapSampler(source, CreatePixelData(overrides: new Dictionary<int, BlockPixelData>
        {
            [8] = Pixel(8, 128, 64, 32, changesWithEnvironment: true),
        }));

        var color = sampler.Sample(1, 2);

        // Temperature 0 receives a +1 height adjustment at Y=54. The grass palette
        // therefore interpolates its cold and warm corners by 1/8 before multiplication.
        Assert.Equal(new Rgba32(79, 46, 22, 255), color);
    }

    [Fact]
    public void Production_environment_color_source_takes_precedence_over_the_fallback_approximation()
    {
        var source = new FakeTerrainMapSource(
            topHeight: 64,
            defaultContent: 8,
            seasonalTemperature: 5,
            seasonalHumidity: 9)
        {
            EnvironmentColor = (content, temperature, humidity) =>
                content == 8 && temperature == 5 && humidity == 9
                    ? new Rgba32(12, 34, 56, 255)
                    : null,
        };
        var sampler = new TerrainMapSampler(source, CreatePixelData(overrides: new Dictionary<int, BlockPixelData>
        {
            [8] = Pixel(8, 171, 171, 171, changesWithEnvironment: true),
        }));

        var color = sampler.Sample(3, 4);

        Assert.Equal(new Rgba32(8, 22, 37, 255), color);
    }

    [Fact]
    public void Ordinary_content_returns_the_configured_base_color_without_environment_or_night_tint()
    {
        var source = new FakeTerrainMapSource(topHeight: 90, defaultContent: 7);
        var sampler = new TerrainMapSampler(source, CreatePixelData(overrides: new Dictionary<int, BlockPixelData>
        {
            [7] = Pixel(7, 211, 196, 149, alpha: 255),
        }));

        var color = sampler.Sample(100, 200);

        Assert.Equal(new Rgba32(211, 196, 149, 255), color);
        Assert.Empty(source.TemperatureCalls);
        Assert.Empty(source.HumidityCalls);
    }

    [Theory]
    [InlineData(262)]
    [InlineData(263)]
    [InlineData(int.MaxValue)]
    public void Future_modded_content_uses_a_stable_opaque_fallback_instead_of_dropping_the_chunk(int content)
    {
        var source = new FakeTerrainMapSource(topHeight: 64, defaultContent: content);
        var sampler = new TerrainMapSampler(source, CreatePixelData());

        var first = sampler.Sample(-21, -36);
        var second = sampler.Sample(-21, -36);

        Assert.Equal(first, second);
        Assert.Equal(byte.MaxValue, first.A);
        Assert.NotEqual(default, first);
        Assert.Empty(source.TemperatureCalls);
        Assert.Empty(source.HumidityCalls);
    }

    [Fact]
    public void Chunk_with_future_modded_content_is_sampled_completely()
    {
        var source = new FakeTerrainMapSource(topHeight: 64, defaultContent: 263);
        var sampler = new TerrainMapSampler(source, CreatePixelData());
        var destination = new Rgba32[TerrainChunkCoordinate.PixelCount];

        var sampled = sampler.TrySampleChunk(new TerrainChunkCoordinate(-2, -3), destination);

        Assert.True(sampled);
        Assert.All(destination, color => Assert.Equal(byte.MaxValue, color.A));
    }

    [Fact]
    public void Json_dictionary_is_loaded_once_and_sampling_does_not_read_the_stream_again()
    {
        using var inner = CreatePixelJsonStream();
        using var stream = new CountingReadStream(inner);
        var source = new FakeTerrainMapSource(topHeight: 64, defaultContent: 1);
        var sampler = new TerrainMapSampler(source, stream);
        var readsAfterConstruction = stream.ReadCount;

        sampler.Sample(0, 0);
        sampler.Sample(1, 1);

        Assert.True(readsAfterConstruction > 0);
        Assert.Equal(readsAfterConstruction, stream.ReadCount);
    }

    [Fact]
    public void Json_dictionary_rejects_a_missing_color_key_with_a_descriptive_error()
    {
        using var stream = CreatePixelJsonStream(excludedKey: 42);

        var exception = Assert.Throws<InvalidDataException>(
            () => new TerrainMapSampler(new FakeTerrainMapSource(), stream));

        Assert.Contains("42", exception.Message, StringComparison.Ordinal);
        Assert.Contains("0..256", exception.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void Json_dictionary_rejects_keys_outside_the_supported_range()
    {
        using var stream = CreatePixelJsonStream(addExtraKey: true);

        var exception = Assert.Throws<InvalidDataException>(
            () => new TerrainMapSampler(new FakeTerrainMapSource(), stream));

        Assert.Contains("257", exception.Message, StringComparison.Ordinal);
        Assert.Contains("0..256", exception.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void Json_dictionary_rejects_a_transparent_non_air_color()
    {
        using var stream = CreatePixelJsonStream(transparentKey: 42);

        var exception = Assert.Throws<InvalidDataException>(
            () => new TerrainMapSampler(new FakeTerrainMapSource(), stream));

        Assert.Contains("42", exception.Message, StringComparison.Ordinal);
        Assert.Contains("transparent", exception.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void Json_dictionary_rejects_an_opaque_air_color()
    {
        using var stream = CreatePixelJsonStream(opaqueAir: true);

        var exception = Assert.Throws<InvalidDataException>(
            () => new TerrainMapSampler(new FakeTerrainMapSource(), stream));

        Assert.Contains("0", exception.Message, StringComparison.Ordinal);
        Assert.Contains("transparent", exception.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void Bundled_color_asset_contains_exactly_257_valid_entries()
    {
        var path = Path.Combine(
            TestPaths.RepositoryRoot,
            "src",
            "SurvivalcraftTravelMap",
            "Assets",
            "BlockPixelColor.json");
        using var stream = File.OpenRead(path);

        var entries = BlockPixelData.LoadDictionary(stream);

        Assert.Equal(Enumerable.Range(0, 257), entries.Keys.Order());
        Assert.Equal(
            [8, 12, 13, 14, 18, 19, 225, 256],
            entries.Values
                .Where(entry => entry.NeedChangeWithEnvironment)
                .Select(entry => entry.BlockIndex)
                .Order()
                .ToArray());

        var hash = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(path)));
        Assert.NotEqual("656ECD47A8C01514A3B4F6D90E6EC7AFE2B0590A31758825C7A64B311FC0D55A", hash);

        Assert.Equal(new Rgba32(0, 0, 0, 0), entries[0].Color); // Air.
        Assert.Equal(new Rgba32(97, 97, 97, 255), entries[1].Color); // Stone.
        Assert.Equal(new Rgba32(132, 106, 58, 255), entries[2].Color); // Dirt.
        Assert.Equal(new Rgba32(211, 196, 149, 255), entries[7].Color); // Sand.
        Assert.Equal(new Rgba32(198, 154, 83, 255), entries[9].Color); // Oak wood.
        Assert.Equal(new Rgba32(233, 122, 29, 255), entries[92].Color); // Magma.
        Assert.Equal(new Rgba32(92, 116, 52, 255), entries[127].Color); // Cactus.
        Assert.Equal(new Rgba32(171, 171, 171, 255), entries[8].Color); // Runtime grass multiplier.
        Assert.Equal(new Rgba32(168, 168, 168, 255), entries[18].Color); // Runtime water multiplier.
        Assert.Equal(new Rgba32(165, 165, 165, 165), entries[57].Color); // Translucent glass.
        Assert.Equal(
            [0],
            entries.Values
                .Where(entry => entry.Color.A == 0)
                .Select(entry => entry.BlockIndex)
                .ToArray());

        Assert.All(entries, pair =>
            Assert.Equal(LegacyTerrainPaletteMigration.GetReferenceColor(pair.Key), pair.Value.Color));
    }

    [Fact]
    public void Project_palette_generator_reproduces_the_bundled_asset()
    {
        using var temporary = new TemporaryDirectory();
        var generatedPath = Path.Combine(temporary.Path, "BlockPixelColor.json");
        var generator = Path.Combine(TestPaths.RepositoryRoot, "tools", "Generate-BlockPalette.ps1");

        var result = PowerShellRunner.Run(generator, generatedPath);

        Assert.Equal(0, result.ExitCode);
        Assert.Equal(
            File.ReadAllBytes(Path.Combine(
                TestPaths.RepositoryRoot,
                "src",
                "SurvivalcraftTravelMap",
                "Assets",
                "BlockPixelColor.json")),
            File.ReadAllBytes(generatedPath));
    }

    public static TheoryData<int> TransparentTopCases => new(TransparentTopContents);

    public static TheoryData<int> WaterVariantCases => new(WaterVariantContents);

    private static bool TrySampleChunkAndCommit(
        TerrainMapSampler sampler,
        TerrainChunkCoordinate chunk,
        MapTile tile,
        Rgba32[] staging)
    {
        if (!sampler.TrySampleChunk(chunk, staging))
        {
            return false;
        }

        tile.SetRegion(
            x: 16,
            z: 32,
            TerrainChunkCoordinate.Size,
            TerrainChunkCoordinate.Size,
            staging);
        return true;
    }

    private static MapTile CreateSeededTile()
    {
        var tile = new MapTile(0, 0);
        tile.SetPixel(1, 2, new Rgba32(11, 22, 33, 255));
        tile.SetPixel(48, 50, new Rgba32(44, 55, 66, 255));
        return tile;
    }

    private static (long Version, byte[] Explored, byte[] Colors) CaptureTileState(MapTile tile)
    {
        var explored = new byte[MapTile.ExploredByteCount];
        var colors = new byte[MapTile.ColorByteCount];
        tile.CopyExploredTo(explored);
        tile.CopyColorsTo(colors);
        return (tile.Version, explored, colors);
    }

    private static void AssertTileStateUnchanged(
        (long Version, byte[] Explored, byte[] Colors) expected,
        MapTile actual)
    {
        var actualState = CaptureTileState(actual);
        Assert.Equal(expected.Version, actualState.Version);
        Assert.True(expected.Explored.AsSpan().SequenceEqual(actualState.Explored));
        Assert.True(expected.Colors.AsSpan().SequenceEqual(actualState.Colors));
    }

    internal static IReadOnlyDictionary<int, BlockPixelData> CreatePixelData(
        IReadOnlyDictionary<int, BlockPixelData>? overrides = null)
    {
        var result = Enumerable.Range(0, 257)
            .ToDictionary(
                index => index,
                index => Pixel(index, 1, 2, 3, alpha: index == 0 ? (byte)0 : (byte)255));

        if (overrides is not null)
        {
            foreach (var pair in overrides)
            {
                result[pair.Key] = pair.Value;
            }
        }

        return result;
    }

    private static BlockPixelData Pixel(
        int index,
        byte r,
        byte g,
        byte b,
        byte alpha = 255,
        bool changesWithEnvironment = false) =>
        new(index, new Rgba32(r, g, b, alpha), changesWithEnvironment);

    private static MemoryStream CreatePixelJsonStream(
        int? excludedKey = null,
        bool addExtraKey = false,
        int? transparentKey = null,
        bool opaqueAir = false)
    {
        var data = Enumerable.Range(0, 257)
            .Where(index => index != excludedKey)
            .ToDictionary(
                index => index.ToString(),
                index => new
                {
                    BlockIndex = index,
                    Color = new
                    {
                        R = index % 256,
                        G = 20,
                        B = 30,
                        A = index == transparentKey || (index == 0 && !opaqueAir) ? 0 : 255,
                    },
                    NeedChangeWithEnvironment = false,
                });

        if (addExtraKey)
        {
            data["257"] = new
            {
                BlockIndex = 257,
                Color = new { R = 1, G = 2, B = 3, A = 255 },
                NeedChangeWithEnvironment = false,
            };
        }

        return new MemoryStream(JsonSerializer.SerializeToUtf8Bytes(data));
    }
}

internal sealed class FakeTerrainMapSource(
    int topHeight = 64,
    int defaultContent = 1,
    int seasonalTemperature = 8,
    int seasonalHumidity = 8,
    bool isReady = true) : ITerrainMapSource
{
    private readonly Dictionary<(int X, int Y, int Z), int> _contents = [];
    private readonly Dictionary<(int X, int Z), Exception> _topHeightFailures = [];
    private readonly Dictionary<(int X, int Z), int> _topHeights = [];

    internal List<(int X, int Y, int Z)> ContentCalls { get; } = [];

    internal List<(int X, int Z)> SampledColumns { get; } = [];

    internal List<(int X, int Z)> TemperatureCalls { get; } = [];

    internal List<(int X, int Z)> HumidityCalls { get; } = [];

    internal int ColumnReadinessChecks { get; private set; }

    internal int ChunkReadinessChecks { get; private set; }

    internal List<TerrainChunkCoordinate> RequestedChunks { get; } = [];

    internal HashSet<int> CrossPlantContents { get; } = [];

    internal Func<int, int, int, Rgba32?>? EnvironmentColor { get; init; }

    internal void SetContent(int x, int y, int z, int content) => _contents[(x, y, z)] = content;

    internal void SetTopHeight(int x, int z, int height) => _topHeights[(x, z)] = height;

    internal void ThrowFromTopHeightAt(int x, int z, Exception exception) =>
        _topHeightFailures[(x, z)] = exception;

    public bool IsColumnReady(int x, int z)
    {
        ColumnReadinessChecks++;
        return isReady;
    }

    public bool IsChunkSurfaceReady(TerrainChunkCoordinate chunk)
    {
        ChunkReadinessChecks++;
        RequestedChunks.Add(chunk);
        return isReady;
    }

    public int GetTopHeight(int x, int z)
    {
        SampledColumns.Add((x, z));
        if (_topHeightFailures.TryGetValue((x, z), out var exception))
        {
            throw exception;
        }

        return _topHeights.GetValueOrDefault((x, z), topHeight);
    }

    public int GetContent(int x, int y, int z)
    {
        ContentCalls.Add((x, y, z));
        return _contents.GetValueOrDefault((x, y, z), defaultContent);
    }

    public int GetSeasonalTemperature(int x, int z)
    {
        TemperatureCalls.Add((x, z));
        return seasonalTemperature;
    }

    public int GetSeasonalHumidity(int x, int z)
    {
        HumidityCalls.Add((x, z));
        return seasonalHumidity;
    }

    public bool IsCrossPlant(int content) => CrossPlantContents.Contains(content);

    public bool TryGetEnvironmentColor(
        int content,
        int temperature,
        int humidity,
        out Rgba32 color)
    {
        var result = EnvironmentColor?.Invoke(content, temperature, humidity);
        color = result.GetValueOrDefault();
        return result.HasValue;
    }
}

internal sealed class CountingReadStream(Stream inner) : Stream
{
    internal int ReadCount { get; private set; }

    public override bool CanRead => inner.CanRead;
    public override bool CanSeek => inner.CanSeek;
    public override bool CanWrite => false;
    public override long Length => inner.Length;

    public override long Position
    {
        get => inner.Position;
        set => inner.Position = value;
    }

    public override void Flush() => inner.Flush();

    public override int Read(byte[] buffer, int offset, int count)
    {
        ReadCount++;
        return inner.Read(buffer, offset, count);
    }

    public override int Read(Span<byte> buffer)
    {
        ReadCount++;
        return inner.Read(buffer);
    }

    public override long Seek(long offset, SeekOrigin origin) => inner.Seek(offset, origin);
    public override void SetLength(long value) => throw new NotSupportedException();
    public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
}
