using SurvivalcraftTravelMap.UI;
using Xunit;

namespace SurvivalcraftTravelMap.Tests;

public sealed class HiddenMouseGestureFilterTests
{
    [Fact]
    public void Hidden_cursor_press_frame_is_a_mouse_gesture()
    {
        var filter = new HiddenMouseGestureFilter();

        Assert.True(filter.Update(isMouseCursorVisible: false, mouseButtonPressedOnce: true, mouseButtonHeld: true));
    }

    [Fact]
    public void Hidden_cursor_release_frame_after_press_is_a_mouse_gesture()
    {
        var filter = new HiddenMouseGestureFilter();
        filter.Update(isMouseCursorVisible: false, mouseButtonPressedOnce: true, mouseButtonHeld: true);

        Assert.True(filter.Update(isMouseCursorVisible: false, mouseButtonPressedOnce: false, mouseButtonHeld: false));
        Assert.False(filter.Update(isMouseCursorVisible: false, mouseButtonPressedOnce: false, mouseButtonHeld: false));
    }

    [Fact]
    public void Rapid_hidden_cursor_clicks_stay_filtered_every_frame()
    {
        var filter = new HiddenMouseGestureFilter();
        for (var frame = 0; frame < 30; frame++)
        {
            var pressed = frame % 2 == 0;
            Assert.True(filter.Update(isMouseCursorVisible: false, mouseButtonPressedOnce: pressed, mouseButtonHeld: false));
        }
    }

    [Fact]
    public void Touch_without_mouse_buttons_is_not_filtered()
    {
        var filter = new HiddenMouseGestureFilter();

        Assert.False(filter.Update(isMouseCursorVisible: false, mouseButtonPressedOnce: false, mouseButtonHeld: false));
    }

    [Fact]
    public void Visible_cursor_clicks_are_not_filtered()
    {
        var filter = new HiddenMouseGestureFilter();

        Assert.False(filter.Update(isMouseCursorVisible: true, mouseButtonPressedOnce: true, mouseButtonHeld: true));
        Assert.False(filter.Update(isMouseCursorVisible: true, mouseButtonPressedOnce: false, mouseButtonHeld: false));
    }
}
