using System.Numerics;
using System.Text;
using Engine.Graphics;
using Engine.Input;
using Game;
using Game.NetWork;
using Game.NetWork.Packages;
using GameEntitySystem;
using SurvivalcraftTravelMap.Map;
using SurvivalcraftTravelMap.Network;
using SurvivalcraftTravelMap.Persistence;
using SurvivalcraftTravelMap.Settings;
using SurvivalcraftTravelMap.Teleport;
using SurvivalcraftTravelMap.UI;
using SurvivalcraftTravelMap.Waypoints;
using TemplatesDatabase;

namespace SurvivalcraftTravelMap.Mod;

public enum TravelMapWorkType
{
    Local,
    Server,
    Client,
}

public readonly record struct TravelMapRuntimeContext(
    TravelMapWorkType WorkType,
    bool IsMainPlayer,
    bool HasUi);

public static class TravelMapRuntimePolicy
{
    public static bool CreatesUi(TravelMapRuntimeContext context) =>
        context.IsMainPlayer && context.HasUi;

    public static bool CreatesTeleportService(TravelMapWorkType workType) => workType is not TravelMapWorkType.Client;

    public static bool AllowsDirectPositionWrite(TravelMapRuntimeContext context) =>
        context.WorkType == TravelMapWorkType.Local;

    public static bool UsesAuthoritativeHostTeleport(TravelMapRuntimeContext context) =>
        context.WorkType == TravelMapWorkType.Server && CreatesUi(context);

    public static bool UsesLocalWorldStorage(TravelMapRuntimeContext context) =>
        context.WorkType == TravelMapWorkType.Local
        || (context.WorkType == TravelMapWorkType.Server && context.IsMainPlayer);

    public static bool CreatesInvitationUi(TravelMapRuntimeContext context) =>
        context.WorkType != TravelMapWorkType.Local && CreatesUi(context);

    public static void CleanupRuntime(
        Action cancelLifetime,
        Action releaseChunks,
        Action disposeDispatcher,
        Action finalCleanup)
    {
        ArgumentNullException.ThrowIfNull(cancelLifetime);
        ArgumentNullException.ThrowIfNull(releaseChunks);
        ArgumentNullException.ThrowIfNull(disposeDispatcher);
        ArgumentNullException.ThrowIfNull(finalCleanup);
        try
        {
            cancelLifetime();
        }
        finally
        {
            try
            {
                releaseChunks();
            }
            finally
            {
                try
                {
                    disposeDispatcher();
                }
                finally
                {
                    finalCleanup();
                }
            }
        }
    }
}

public sealed class TravelMapComponent : Component, IUpdateable
{
    private const int MaximumChunkAttemptsPerFrame = 16;
    private const int MaximumCaveChunkAttemptsPerFrame = 2;
    private const int MaximumCoverageChecksPerFrame = 16;

    // Under write pressure every recording attempt is refused, so retrying 16 chunks a frame only
    // heats the device. Idle for slightly longer than one flush interval so the backlog gets a
    // whole cycle to drain before exploration starts competing with it again.
    private const float StoragePressureBackoffSeconds = 6f;
    private const float StoragePressureDiagnosticSeconds = 10f;
    private static int s_nextUpdateLocationId = -1_000_000;
    private static readonly CoordinateTeleportFutureSchemaWarningGate ServerSettingsWarningGate = new();
    private static readonly TravelMapSettingsFutureSchemaWarningGate SettingsWarningGate = new();

    private readonly CancellationTokenSource _lifetimeCancellation = new();
    private readonly TerrainChunkExplorationScheduler _explorationScheduler = new();
    private readonly ExplorationFailureReporter _explorationFailureReporter = new(LogExplorationFailure);
    private readonly TravelMapUiController _uiController = new();
    private readonly HiddenMouseGestureFilter _openMapButtonMouseGestures = new();
    private readonly IdempotentTravelMapCleanup _runtimeCleanup;
    private GameUpdateDispatcher? _dispatcher;
    private SurvivalcraftChunkLoader? _chunkLoader;
    private TravelMapSettingsStore? _settingsStore;
    private TravelMapSettings? _settings;
    private ExplorationTileStore? _tileStore;
    private SurvivalcraftTerrainMapSource? _terrainMapSource;
    private CaveExplorationStore? _caveStore;
    private ExplorationRecorder? _explorationRecorder;
    private CaveMapSampler? _caveSampler;
    private ExplorationCoverageProbe? _explorationCoverageProbe;
    private MapViewState? _mapViewState;
    private WaypointRepository? _waypointRepository;
    private DismissedDeathStore? _dismissedDeathStore;
    private readonly HashSet<DeathMarkerIdentity> _dismissedDeaths = new();
    private CurrentPositionWaypointHandler? _currentPositionWaypointHandler;
    private IReadOnlyList<Waypoint> _waypoints = Array.Empty<Waypoint>();
    private MiniMapRenderer? _miniMap;
    private TravelMapDialog? _largeMapDialog;
    private MiniMapPlacementWidget? _miniMapPlacementWidget;
    private MiniMapPlacementSession? _miniMapPlacementSession;
    private Task? _miniMapPlacementSaveTask;
    private TrackedUiActionRunner? _uiActions;
    private Task? _flushTask;
    private readonly object _networkSync = new();
    private CoordinateTeleportServerSession? _coordinateServerSession;
    private AuthoritativeHostTeleportSession? _authoritativeHostTeleport;
    private CoordinateTeleportClientSession? _coordinateClientSession;
    private CoordinateTeleportServerOptions _coordinateServerOptions = new();
    private TrackedUiActionRunner? _networkActions;
    private TeleportPanelWidget? _teleportPanel;
    private BitmapButtonWidget? _teleportPanelButton;
    private BevelledButtonWidget? _openMapButton;
    private Texture2D? _teleportButtonTexture;
    private Texture2D? _teleportButtonPressedTexture;
    private float _flushElapsed;
    private bool _explorationPressureWarningShown;
    private float _storagePressureBackoff;
    private float _storagePressureDiagnosticCooldown;
    private const int ExplorationObserveIntervalFrames = 30;
    private TerrainChunkCoordinate? _lastObservedCenter;
    private int _framesSinceExplorationObserve;
    private TerrainChunkCoordinate[] _cachedLoadedChunks = Array.Empty<TerrainChunkCoordinate>();
    private bool _isActive;
    private bool _persistenceWarningShown;

    public TravelMapComponent()
    {
        _runtimeCleanup = new IdempotentTravelMapCleanup(CleanupRuntimeResources);
    }

    internal ComponentPlayer Player { get; private set; } = null!;

    internal SubsystemTerrain Terrain { get; private set; } = null!;

    internal SubsystemTimeOfDay TimeOfDay { get; private set; } = null!;

    internal SubsystemCreatureSpawn? CreatureSpawn { get; private set; }

    internal ComponentGui? Gui { get; private set; }

    internal SafeTeleportService? TeleportService { get; private set; }

    internal CancellationToken LifetimeToken => _lifetimeCancellation.Token;

    public TravelMapWorkType WorkType { get; private set; }

    public TravelMapRuntimeContext RuntimeContext { get; private set; }

    public Action<TravelMapClientTravelCommand>? ClientTravelCommand { get; set; }

    public UpdateOrder UpdateOrder => UpdateOrder.Views;

    public override void Load(ValuesDictionary valuesDictionary, IdToEntityMap idToEntityMap)
    {
        base.Load(valuesDictionary, idToEntityMap);
        if (!TravelMapStartup.EnsureInitialized(
                packageName => ModsManager.GetModEntity(packageName, out _),
                PackageManager.RegisterPackage,
                message => Engine.Log.Warning($"[TravelMap] {message}"),
                message => Engine.Log.Warning($"[TravelMap] {message}")))
        {
            return;
        }

        var uiState = new UiInitializationState();
        Action[] stages =
        [
            InitializeCoreRuntime,
            () => InitializeUiSettings(uiState),
            () => InitializeUiPersistence(uiState),
            TryCreateExplorationRecorder,
            () => AttachUiWidgets(uiState),
        ];

        _isActive = TravelMapLoadTransaction.TryRun(
            stages,
            _runtimeCleanup.Run,
            exception => Engine.Log.Warning(
                $"[TravelMap] Player component activation failed; the component is inert: {exception.Message}"));
        if (_isActive)
        {
            Engine.Log.Information(
                $"[TravelMap] Player component active: workType={WorkType}, main={RuntimeContext.IsMainPlayer}, ui={_miniMap is not null}.");
        }
    }

    public void Update(float dt)
    {
        if (!_isActive)
        {
            return;
        }

        _dispatcher?.Pump();
        if (WorkType == TravelMapWorkType.Server && Project is ProjectNet projectNet)
        {
            TravelMapNetworkRuntime.UpdateLegacyServer(projectNet, CommonLib.Net);
        }

        var hudState = TravelMapHudPolicy.Evaluate(GetHudSignals());
        ApplyHudState(hudState);
        UpdateHudPositions();
        UpdateMiniMapPlacement();
        UpdateInvitationUi(hudState);
        UpdateOpenMapButton();
        UpdateExploration(dt);
        if (_miniMapPlacementSession is null)
        {
            HandleLargeMapHotkey();
        }
        else
        {
            // Placement drags cover the screen the same way the large map does, and leak into the
            // movement pads for the same reason.
            ReleaseGameTouchCaptures();
        }
        if (_miniMap is null || _settings is null)
        {
            return;
        }

        UpdateFlush(dt);
    }

    public async Task<TeleportResult> TeleportToSurfaceAsync(
        int x,
        int z,
        CancellationToken cancellationToken)
    {
        using var diagnosticScope = TeleportDiagnosticContext.Ensure(
            new TeleportRequestDiagnosticContext("local", null, "SurfaceRequest"));
        var service = GetLocalTeleportService();
        using var linkedCancellation = CancellationTokenSource.CreateLinkedTokenSource(
            cancellationToken,
            _lifetimeCancellation.Token);
        var result = await service.TeleportToSurfaceAsync(x, z, linkedCancellation.Token);
        ShowMessage(TravelMapNoticeFactory.For(result));
        return result;
    }

    public async Task<TeleportResult> TeleportToWaypointAsync(
        Vector3 xyz,
        CancellationToken cancellationToken)
    {
        using var diagnosticScope = TeleportDiagnosticContext.Ensure(
            new TeleportRequestDiagnosticContext("local", null, "WaypointRequest"));
        var service = GetLocalTeleportService();
        using var linkedCancellation = CancellationTokenSource.CreateLinkedTokenSource(
            cancellationToken,
            _lifetimeCancellation.Token);
        var result = await service.TeleportToWaypointAsync(xyz, linkedCancellation.Token);
        ShowMessage(TravelMapNoticeFactory.For(result));
        return result;
    }

    public override void OnEntityRemoved()
    {
        _runtimeCleanup.Run();
        base.OnEntityRemoved();
    }

    private SafeTeleportService GetLocalTeleportService()
    {
        if (!TravelMapRuntimePolicy.AllowsDirectPositionWrite(RuntimeContext) || TeleportService is null)
        {
            throw new InvalidOperationException(
                "Direct player movement is only available in a local world. Multiplayer travel requires server authorization.");
        }

        return TeleportService;
    }

    private static TravelMapWorkType ToTravelMapWorkType(WorkType workType) => workType switch
    {
        Game.NetWork.WorkType.Local => TravelMapWorkType.Local,
        Game.NetWork.WorkType.Server => TravelMapWorkType.Server,
        Game.NetWork.WorkType.Client => TravelMapWorkType.Client,
        _ => throw new InvalidOperationException($"Unsupported Survivalcraft work type: {workType}."),
    };

    internal TravelMapBoundPeer? TryBindNetworkPeer(Client source) =>
        _isActive && WorkType == TravelMapWorkType.Server
            ? TravelMapBoundPeer.TryCreate(source, Player, LifetimeToken)
            : null;

    internal async Task<CoordinateTeleportMessage> HandleCoordinateServerAsync(
        TravelMapBoundPeer binding,
        CoordinateTeleportMessage message,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(binding);
        ArgumentNullException.ThrowIfNull(message);
        using var diagnosticScope = TeleportDiagnosticContext.Ensure(
            new TeleportRequestDiagnosticContext(
                "remote",
                message.RequestId,
                message.Kind.ToString()));
        var sourceIdentity = binding.Identity;
        CoordinateTeleportServerSession session;
        lock (_networkSync)
        {
            if (WorkType != TravelMapWorkType.Server
                || TeleportService is null
                || !binding.IsCurrent)
            {
                var rejected = CoordinateTeleportMessage.Result(
                    message.RequestId,
                    CoordinateTeleportResultCode.Rejected);
                ShowMessage(TravelMapNoticeFactory.For(CoordinateTeleportResultCode.Rejected));
                return rejected;
            }

            _coordinateServerSession ??= new CoordinateTeleportServerSession(
                sourceIdentity,
                new SafeTeleportExecutor(TeleportService),
                _coordinateServerOptions);
            session = _coordinateServerSession;
        }

        var response = await CoordinateTeleportBoundOperation.ExecuteAsync(
            binding,
            session,
            message,
            cancellationToken).ConfigureAwait(false);
        ReportCoordinateTeleportResult("remote", message, response.ResultCode);
        if (response.ResultCode is { } result)
        {
            ShowMessage(TravelMapNoticeFactory.For(result));
        }

        return response;
    }

    internal bool ReceiveCoordinateServerMessage(Client source, CoordinateTeleportMessage message)
    {
        ArgumentNullException.ThrowIfNull(source);
        lock (_networkSync)
        {
            return WorkType == TravelMapWorkType.Client
                && _coordinateClientSession is not null
                && _coordinateClientSession.Receive(
                    TravelMapNetworkPeerIdentity.ForClient(source),
                    message);
        }
    }

    internal async Task<TeleportResult> HandleLegacyTeleportToPlayerAsync(
        Vector3 target,
        CancellationToken cancellationToken)
    {
        using var diagnosticScope = TeleportDiagnosticContext.Ensure(
            new TeleportRequestDiagnosticContext("invitation", null, "Teleport"));
        if (WorkType != TravelMapWorkType.Server || TeleportService is null)
        {
            return TeleportResult.OutOfWorld;
        }

        using var linked = CancellationTokenSource.CreateLinkedTokenSource(
            cancellationToken,
            _lifetimeCancellation.Token);
        var result = await TeleportService.TeleportToWaypointAsync(target, linked.Token).ConfigureAwait(false);
        Engine.Log.Information($"[TravelMap] Legacy invitation teleport result={result}.");
        return result;
    }

    internal void HandleLegacyClientResponse(LegacyGpsMessage message)
    {
        if (_settings is null)
        {
            return;
        }

        var action = LegacyInvitationClientPolicy.Decide(
            message,
            _settings.AcceptTeleportInvitations);
        switch (action)
        {
            case LegacyClientResponseAction.ShowMessage:
                ShowMessage(message.Message ?? string.Empty);
                break;
            case LegacyClientResponseAction.RejectInvitation:
                QueueLegacyPackage(LegacyGpsMessage.TeleportAllow(false));
                ShowMessage(TravelMapText.Get("invitationAutoRejected", "已按设置自动拒绝玩家传送邀请"));
                break;
            case LegacyClientResponseAction.ShowInvitation:
                try
                {
                    _dispatcher?.Invoke(() => DialogsManager.ShowDialog(
                        Player.GuiWidget,
                        new MessageDialog(
                            TravelMapText.Get("teleportInvitation", "玩家传送邀请"),
                            message.Message ?? string.Empty,
                            TravelMapText.Get("accept", "接受"),
                            TravelMapText.Get("decline", "拒绝"),
                            button => QueueLegacyPackage(
                                LegacyGpsMessage.TeleportAllow(button == MessageDialogButton.Button1)))));
                }
                catch (ObjectDisposedException)
                {
                }

                break;
        }
    }

    private void InitializeCoordinateClient()
    {
        if (!TravelMapStartup.IsCoordinateTeleportAvailable)
        {
            ShowMessage(
                TravelMapText.Get(
                    "networkPackageConflict",
                    "地图网络通道被其他模组占用（数据包ID冲突），联机传送暂不可用；地图其他功能不受影响"),
                TravelMapNoticeKind.Failure);
            return;
        }

        var server = CommonLib.Net.Server;
        if (server is null)
        {
            ShowMessage(CoordinateTeleportClientSession.UnsupportedOrTimeoutMessage);
            return;
        }

        // CommonLib.Net.Server is a transient wrapper whose PlayerGuid is empty and whose TokenId is
        // random, but inbound replies resolve From to the real synced server entry (Clients[0], the
        // ID-0 client with the real GUID/token). Key the session to that real identity so replies are
        // not discarded as coming from an unexpected peer, which otherwise makes every client-side map
        // teleport time out. Fall back to the wrapper if the real entry is not resolvable yet.
        var serverIdentityClient = CommonLib.Net.GetClientByID(0) ?? server;
        _networkActions = new TrackedUiActionRunner(
            _ => ShowMessage(
                TravelMapText.Get("onlineTravelFailed", "联机旅行请求未能完成"),
                TravelMapNoticeKind.Failure));
        _coordinateClientSession = new CoordinateTeleportClientSession(
            TravelMapNetworkPeerIdentity.ForClient(serverIdentityClient),
            message =>
            {
                var package = new CoordinateTeleportPackage(message) { To = server };
                CommonLib.Net.QueuePackage(package);
            },
            new SystemCoordinateTeleportProtocolClock(),
            message => ShowMessage(message));
        ClientTravelCommand = QueueCoordinateClientCommand;
    }

    private void QueueCoordinateClientCommand(TravelMapClientTravelCommand command)
    {
        var runner = _networkActions;
        if (runner is null || !runner.TryRun(token => SendCoordinateClientCommandAsync(command, token)))
        {
            ShowMessage(
                TravelMapText.Get("onlineTravelBusy", "另一项联机旅行请求仍在进行"),
                TravelMapNoticeKind.Information);
        }
    }

    private async Task SendCoordinateClientCommandAsync(
        TravelMapClientTravelCommand command,
        CancellationToken cancellationToken)
    {
        CoordinateTeleportClientSession? session;
        lock (_networkSync)
        {
            session = _coordinateClientSession;
        }

        if (session is null)
        {
            ShowMessage(CoordinateTeleportClientSession.UnsupportedOrTimeoutMessage);
            return;
        }

        var result = command.Mode == TravelMapClientTravelMode.Surface
            ? await session.RequestSurfaceAsync(
                checked((int)MathF.Floor(command.Target.X)),
                checked((int)MathF.Floor(command.Target.Z)),
                cancellationToken).ConfigureAwait(false)
            : await session.RequestWaypointAsync(command.Target, cancellationToken).ConfigureAwait(false);
        ShowMessage(TravelMapNoticeFactory.For(result));
    }

    private void InitializeCoreRuntime()
    {
        var player = Entity.FindComponent<ComponentPlayer>(true)
            ?? throw new InvalidOperationException("TravelMapComponent must be attached to a player entity.");
        var playerBody = player.ComponentBody
            ?? throw new InvalidOperationException("The travel-map player does not have a body component.");
        Player = player;
        Terrain = Project.FindSubsystem<SubsystemTerrain>(true);
        TimeOfDay = Project.FindSubsystem<SubsystemTimeOfDay>(true);
        CreatureSpawn = Project.FindSubsystem<SubsystemCreatureSpawn>(false);
        WorkType = ToTravelMapWorkType(CommonLib.WorkType);
        RuntimeContext = new TravelMapRuntimeContext(
            WorkType,
            player.PlayerData.IsMainPlayer,
            player.ComponentGui is not null);
        if (WorkType == TravelMapWorkType.Server)
        {
            try
            {
                var optionsPath = Engine.Storage.GetSystemPath(
                    "data:/SurvivalcraftTravelMap/server-settings.json");
                var loadResult = new CoordinateTeleportServerOptionsStore(optionsPath).LoadWithOutcome();
                _coordinateServerOptions = loadResult.Options;
                ServerSettingsWarningGate.NotifyIfNeeded(loadResult, static message => Engine.Log.Warning(message));
            }
            catch (Exception exception) when (exception is IOException or UnauthorizedAccessException)
            {
                Engine.Log.Warning($"[TravelMap] Server teleport settings could not be loaded: {exception.Message}");
                _coordinateServerOptions = new CoordinateTeleportServerOptions();
            }
        }

        Gui = TravelMapRuntimePolicy.CreatesUi(RuntimeContext)
            ? player.ComponentGui
            : null;
        _dispatcher = new GameUpdateDispatcher();
        if (!TravelMapRuntimePolicy.CreatesTeleportService(WorkType))
        {
            return;
        }

        var bodies = Project.FindSubsystem<SubsystemBodies>(true);
        var terrainAccess = new SurvivalcraftTerrainAccess(
            Terrain,
            playerBody,
            bodies,
            _dispatcher);
        var clock = new SurvivalcraftTeleportClock(_dispatcher);
        var updateLocationId = Interlocked.Decrement(ref s_nextUpdateLocationId);
        _chunkLoader = new SurvivalcraftChunkLoader(
            Terrain,
            updateLocationId,
            _dispatcher,
            clock);
        var playerMover = new SurvivalcraftPlayerMover(Player, _dispatcher);
        TeleportService = new SafeTeleportService(
            terrainAccess,
            _chunkLoader,
            playerMover,
            terrainAccess,
            WorkType == TravelMapWorkType.Server
                ? new GameUpdateTeleportPositionCommitter(
                    _dispatcher,
                    QueueAuthoritativePositionSync)
                : new GameUpdateTeleportPositionCommitter(
                    _dispatcher,
                    static _ => { }),
            clock,
            TeleportDiagnosticReporter.Report,
            TeleportDiagnosticReporter.ReportSearch);
        if (TravelMapRuntimePolicy.UsesAuthoritativeHostTeleport(RuntimeContext))
        {
            _authoritativeHostTeleport = new AuthoritativeHostTeleportSession(
                $"host:{Player.PlayerGuid:N}",
                new SafeTeleportExecutor(TeleportService),
                _coordinateServerOptions,
                (message, result) => ReportCoordinateTeleportResult("host", message, result));
        }
    }

    // Matches the original 34GPS TPPlayer pattern: re-assert the body position and construct the
    // PositionSet package in the same game-update tick. The package constructor captures the LIVE
    // body position, and for a remote player the client's own BodyUpdate stream (which is
    // position-authoritative in this engine) can interpolate the entity back to its pre-teleport
    // position during the post-move validation frame — broadcasting that stale capture is exactly
    // the "teleport succeeded but nobody moved" bug. Setting the body right before constructing
    // guarantees the broadcast carries the teleport target; the receiving client then applies it
    // and starts reporting the new position itself, which makes it stick everywhere.
    private void QueueAuthoritativePositionSync(System.Numerics.Vector3 committedPosition)
    {
        var body = Player.ComponentBody;
        body.Position = new Engine.Vector3(
            committedPosition.X,
            committedPosition.Y,
            committedPosition.Z);
        body.Velocity = Engine.Vector3.Zero;
        CommonLib.Net.QueuePackage(
            new ComponentPlayerPackage(
                Player,
                ComponentPlayerPackage.PlayerAction.PositionSet));
    }

    private static void ReportCoordinateTeleportResult(
        string route,
        CoordinateTeleportMessage request,
        CoordinateTeleportResultCode? result)
    {
        Engine.Log.Information(
            $"[TravelMap] Coordinate teleport route={route}, request={request.RequestId}, kind={request.Kind}, result={result?.ToString() ?? "Missing"}.");
    }

    private static string ResolveWritableDataRoot()
    {
        // Store writable data under data:/ (a per-user writable location on every platform)
        // instead of app:/ (the game's install directory), which is READ-ONLY on Android and
        // raised "Access denied" — failing activation so no HUD appeared. Best-effort migrate an
        // existing app:/ tree from older desktop installs; copy (not move) so originals survive.
        var dataRoot = Engine.Storage.GetSystemPath("data:/SurvivalcraftTravelMap");
        try
        {
            var legacyRoot = Engine.Storage.GetSystemPath("app:/SurvivalcraftTravelMap");
            if (!string.Equals(legacyRoot, dataRoot, StringComparison.Ordinal)
                && Directory.Exists(legacyRoot)
                && !Directory.Exists(dataRoot))
            {
                CopyDirectoryContents(legacyRoot, dataRoot);
            }
        }
        catch (Exception)
        {
            // Migration is best-effort. Some runtimes (e.g. Android) throw even when merely
            // resolving an app:/ path, so swallow everything and fall back to a fresh data:/ tree.
        }

        return dataRoot;
    }

    private static void CopyDirectoryContents(string source, string destination)
    {
        Directory.CreateDirectory(destination);
        foreach (var file in Directory.EnumerateFiles(source))
        {
            File.Copy(file, Path.Combine(destination, Path.GetFileName(file)), overwrite: false);
        }

        foreach (var directory in Directory.EnumerateDirectories(source))
        {
            CopyDirectoryContents(directory, Path.Combine(destination, Path.GetFileName(directory)));
        }
    }

    private void InitializeUiSettings(UiInitializationState state)
    {
        if (!TravelMapRuntimePolicy.CreatesUi(RuntimeContext))
        {
            return;
        }

        _uiActions = new TrackedUiActionRunner(
            _ => ShowMessage(
                TravelMapText.Get("mapActionFailed", "地图操作未能完成"),
                TravelMapNoticeKind.Failure));
        state.AppRoot = ResolveWritableDataRoot();
        string? legacySettingsPath = null;
        try
        {
            legacySettingsPath = Engine.Storage.GetSystemPath("app:/GPSSetting.xml");
        }
        catch
        {
            // app:/ can be inaccessible (e.g. Android); skip the legacy GPSSetting.xml migration.
        }

        _settingsStore = new TravelMapSettingsStore(state.AppRoot, legacySettingsPath);
        try
        {
            var loadResult = _settingsStore.LoadWithOutcomeAsync(_lifetimeCancellation.Token)
                .GetAwaiter()
                .GetResult();
            _settings = loadResult.Settings;
            SettingsWarningGate.NotifyIfNeeded(loadResult, message => ShowMessage(message));
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException)
        {
            _settings = TravelMapSettings.CreateDefaults();
            _settingsStore.EnterReadOnlyMode();
            WarnPersistenceOnce(TravelMapText.Format(
                "settingsUnavailableFormat",
                "地图设置不可写，本次使用内存默认值：{0}",
                exception.Message));
        }
    }

    private void InitializeUiPersistence(UiInitializationState state)
    {
        if (!TravelMapRuntimePolicy.CreatesUi(RuntimeContext) || _settings is null)
        {
            return;
        }

        var gameInfo = Project.FindSubsystem<SubsystemGameInfo>(true);
        var serverHost = CommonLib.Net.Server?.Peer?.Address?.ToString()
            ?? CommonLib.Net.Server?.IPPoint?.Address.ToString();
        var serverPort = CommonLib.Net.Server?.Peer?.Port
            ?? CommonLib.Net.Server?.IPPoint?.Port;
        var storageScope = TravelMapRuntimePolicy.UsesLocalWorldStorage(RuntimeContext)
            ? TravelMapStorageScope.LocalWorld
            : TravelMapStorageScope.RemoteServer;
        var identity = new TravelMapStorageIdentityInput(
            storageScope,
            state.AppRoot,
            gameInfo.DirectoryName,
            serverHost,
            serverPort,
            gameInfo.DirectoryName,
            Player.PlayerData.PlayerGUID);
        if (!TravelMapStorageIdentity.TryResolve(identity, out var storage, out var identityError))
        {
            Engine.Log.Warning($"[TravelMap] Persistence disabled: {identityError}");
            WarnPersistenceOnce(TravelMapText.Get(
                "persistenceIdentityMissing",
                "缺少可靠的世界或玩家身份，旅行地图持久化已禁用"));
            throw new InvalidOperationException(
                $"Travel-map persistence identity is unavailable: {identityError}");
        }

        try
        {
            // The game recycles local world folder names after a deletion, so a new world can inherit
            // a deleted world's cache directory. Discard it when the stamped seed no longer matches so
            // the previous save's terrain doesn't bleed into this one. Server worlds are keyed by the
            // server identity instead, so this only applies to local storage.
            if (storageScope == TravelMapStorageScope.LocalWorld
                && WorldCacheSeedGuard.Ensure(storage!.Directory, gameInfo.WorldSeed)
                    == WorldCacheSeedGuard.GuardOutcome.Reset)
            {
                Engine.Log.Information(
                    "[TravelMap] Reused world directory detected; cleared stale map cache for a new world.");
            }

            _tileStore = new ExplorationTileStore(Path.Combine(storage!.Directory, "tiles"));
            _caveStore = new CaveExplorationStore(Path.Combine(storage.Directory, "caves"));
            _mapViewState = new MapViewState();
            _waypointRepository = new WaypointRepository(storage.Directory);
            state.WaypointLoadOutcome = _waypointRepository.LoadAsync(_lifetimeCancellation.Token)
                .GetAwaiter()
                .GetResult();
            _waypoints = _waypointRepository.GetAll();
            _dismissedDeathStore = new DismissedDeathStore(storage.Directory);
            _dismissedDeathStore.LoadAsync(_lifetimeCancellation.Token)
                .GetAwaiter()
                .GetResult();
            _dismissedDeaths.Clear();
            _dismissedDeaths.UnionWith(_dismissedDeathStore.Dismissed);
            _currentPositionWaypointHandler = new CurrentPositionWaypointHandler(
                _waypointRepository,
                () =>
                {
                    var position = Player.ComponentBody.Position;
                    return new Vector3(position.X, position.Y, position.Z);
                });
            var surfaceSource = new TileStoreMapPixelSource(_tileStore);
            state.PixelSource = new MapViewPixelSource(
                surfaceSource,
                () => _mapViewState?.Mode ?? MapViewMode.Surface,
                () => _caveStore.GetPixelSource(_mapViewState?.CaveY ?? CaveLayer.CenterForY(64)));
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException)
        {
            _tileStore = null;
            _caveStore = null;
            _mapViewState = null;
            _waypointRepository = null;
            _dismissedDeathStore = null;
            _dismissedDeaths.Clear();
            _currentPositionWaypointHandler = null;
            WarnPersistenceOnce(TravelMapText.Format(
                "persistenceUnavailableFormat",
                "地图与坐标点持久化不可用：{0}",
                exception.Message));
            throw;
        }
    }

    private void AttachUiWidgets(UiInitializationState state)
    {
        if (!TravelMapRuntimePolicy.CreatesUi(RuntimeContext)
            || _settings is null
            || _settingsStore is null)
        {
            return;
        }

        if (TravelMapRuntimePolicy.CreatesInvitationUi(RuntimeContext))
        {
            InitializeInvitationUi();
        }

        if (state.PixelSource is null)
        {
            if (WorkType == TravelMapWorkType.Client)
            {
                InitializeCoordinateClient();
            }

            return;
        }

        _miniMap = new MiniMapRenderer(
            state.PixelSource,
            _settings,
            _settingsStore,
            GetPlayerPose,
            GetVisibleWaypoints,
            GetCreatureMarkers,
            GetLastDeathMarker,
            GetMapBrightness,
            IsMapInputBlocked,
            OpenLargeMap,
            message => ShowMessage(message),
            OpenLargeMapAtLastDeath);
        _miniMap.GameTimeProvider = GetGameTime;
        _miniMap.PreviousDeathProvider = GetPreviousDeathMarker;
        Player.GuiWidget.Children.Add(_miniMap);
        _openMapButton = new BevelledButtonWidget
        {
            Text = TravelMapText.Get("openMap", "地图"),
            Size = new Engine.Vector2(
                TravelMapOverlayLayout.OpenMapButtonSize.X,
                TravelMapOverlayLayout.OpenMapButtonSize.Y),
        };
        Player.GuiWidget.Children.Add(_openMapButton);
        _miniMapPlacementWidget = new MiniMapPlacementWidget(
            ConfirmMiniMapPlacement,
            CancelMiniMapPlacement);
        UpdateHudPositions();

        _largeMapDialog = new TravelMapDialog(
            state.PixelSource,
            _settings,
            _settingsStore,
            GetPlayerPose,
            GetVisibleWaypoints,
            GetCreatureMarkers,
            GetMapBrightness,
            GetGameTime,
            HandleContextActionAsync,
            ShowMessage,
            BeginMiniMapPlacement,
            GetLastDeathMarker,
            _mapViewState,
            GetPreviousDeathMarker,
            ReleaseGameTouchCaptures);
        if (state.WaypointLoadOutcome == WaypointLoadOutcome.CorruptIsolated)
        {
            ShowMessage(
                TravelMapText.Get("waypointFileCorrupt", "坐标点文件已损坏，已隔离并使用空列表"),
                TravelMapNoticeKind.Failure);
        }

        if (WorkType == TravelMapWorkType.Client)
        {
            InitializeCoordinateClient();
        }
    }

    private void TryCreateExplorationRecorder()
    {
        if (_tileStore is null || !ModsManager.GetModEntity("SurvivalcraftTravelMap", out var modEntity))
        {
            return;
        }

        try
        {
            modEntity.GetAssetsFile("BlockPixelColor.json", stream =>
            {
                var terrainSource = new SurvivalcraftTerrainMapSource(Terrain);
                _terrainMapSource = terrainSource;
                var sampler = new TerrainMapSampler(terrainSource, stream);
                _explorationRecorder = new ExplorationRecorder(sampler, _tileStore);
                _caveSampler = new CaveMapSampler(terrainSource, sampler);
                _explorationCoverageProbe = new ExplorationCoverageProbe(
                    _explorationRecorder.IsChunkFullyExplored,
                    _explorationFailureReporter);
            });
        }
        catch (Exception exception) when (exception is IOException or InvalidDataException)
        {
            Engine.Log.Warning($"[TravelMap] Terrain map colors could not be loaded: {exception.Message}");
        }
    }

    private void UpdateHudPositions()
    {
        if (_settings is null)
        {
            return;
        }

        var guiSize = Player.GuiWidget.ActualSize;
        var positions = TravelMapOverlayLayout.PlaceHud(
            new Vector2(guiSize.X, guiSize.Y),
            _settings.MiniMapSize,
            _settings.MiniMapAnchorX,
            _settings.MiniMapAnchorY);
        if (_miniMapPlacementSession is not null)
        {
            positions = positions with { MiniMap = _miniMapPlacementSession.PreviewPosition };
        }

        if (_miniMap is not null)
        {
            SetHudWidgetPosition(_miniMap, positions.MiniMap);
        }

        if (_teleportPanelButton is not null)
        {
            SetHudWidgetPosition(_teleportPanelButton, positions.TeleportButton);
        }

        if (_openMapButton is not null)
        {
            SetHudWidgetPosition(_openMapButton, positions.OpenMapButton);
        }
    }

    private void SetHudWidgetPosition(Widget widget, Vector2 position)
    {
        if (Player.GuiWidget is CanvasWidget canvas)
        {
            canvas.SetWidgetPosition(widget, new Engine.Vector2(position.X, position.Y));
        }
        else
        {
            widget.LayoutTransform = Engine.Matrix.CreateTranslation(position.X, position.Y, 0f);
        }
    }

    private void InitializeInvitationUi()
    {
        _teleportPanel = new TeleportPanelWidget(GetLegacyTeleportPlayers, targetId =>
            QueueLegacyPackage(LegacyGpsMessage.Teleport(targetId.ToString())));
        if (!ModsManager.GetModEntity("SurvivalcraftTravelMap", out var modEntity))
        {
            throw new InvalidOperationException("Travel map assets are unavailable.");
        }

        modEntity.GetAssetsFile("TeleportButton.png", stream =>
            _teleportButtonTexture = Texture2D.Load(stream));
        modEntity.GetAssetsFile("TeleportButton_Pressed.png", stream =>
            _teleportButtonPressedTexture = Texture2D.Load(stream));
        if (_teleportButtonTexture is null || _teleportButtonPressedTexture is null)
        {
            throw new InvalidDataException("Travel map invitation button textures could not be loaded.");
        }

        _teleportPanelButton = new BitmapButtonWidget
        {
            Size = new Engine.Vector2(48f, 46f),
            NormalSubtexture = new Subtexture(
                _teleportButtonTexture,
                Engine.Vector2.Zero,
                Engine.Vector2.One),
            ClickedSubtexture = new Subtexture(
                _teleportButtonPressedTexture,
                Engine.Vector2.Zero,
                Engine.Vector2.One),
        };
        Player.GuiWidget.Children.Add(_teleportPanelButton);
        UpdateHudPositions();
    }

    private void UpdateInvitationUi(TravelMapHudState hudState)
    {
        if (_teleportPanelButton is null || _teleportPanel is null)
        {
            return;
        }

        if (!hudState.ShowTeleportButton
            || !_teleportPanelButton.IsEnabled
            || !GetMapInputFocus().AllowsMapHotkey)
        {
            return;
        }

        // Desktop can only click widgets while the mouse cursor is visible, but the game
        // only shows the cursor when something modal is open — exactly when this HUD
        // button is hidden. The "N" hotkey (next to "M", which the vanilla game leaves
        // unbound; "V" is taken by camera switching) is therefore the keyboard route
        // into the panel; opening it makes it a dialog, which brings the cursor back
        // for the player list itself. Touch input needs no cursor, so the button still
        // serves phones unchanged.
        var input = Player.GameWidget.Input;
        var openRequested = _teleportPanelButton.IsClicked
            || input.IsKeyDownOnce(Engine.Input.Key.N);
        if (openRequested && !DialogsManager.Dialogs.Contains(_teleportPanel))
        {
            _teleportPanel.Refresh();
            DialogsManager.ShowDialog(Player.GuiWidget, _teleportPanel);
            input.Clear();
        }
    }

    private void UpdateOpenMapButton()
    {
        // The always-visible open-map button is the touch-friendly counterpart to the
        // "M" hotkey: phones have no keyboard, so this is their primary way in. It also
        // covers players who hid the mini map (which otherwise doubles as a tap target).
        if (_openMapButton is null)
        {
            return;
        }

        // The button's click comes from the engine's Click gesture, which a hidden mouse also
        // produces at its stale last position while attacking; only touch may click it then.
        var input = Player.GameWidget.Input;
        var isHiddenMouseGesture = _openMapButtonMouseGestures.Update(
            input.IsMouseCursorVisible,
            input.IsMouseButtonDownOnce(MouseButton.Left) || input.IsMouseButtonDownOnce(MouseButton.Right),
            input.IsMouseButtonDown(MouseButton.Left) || input.IsMouseButtonDown(MouseButton.Right));
        if (!_openMapButton.IsEnabled)
        {
            return;
        }

        if (_openMapButton.IsClicked && !isHiddenMouseGesture)
        {
            OpenLargeMap();
        }
    }

    private TravelMapHudSignals GetHudSignals()
    {
        var isLargeMapOpen = _largeMapDialog is not null
            && DialogsManager.Dialogs.Contains(_largeMapDialog);
        var hasModalSurface = Gui?.ModalPanelWidget is not null
            || DialogsManager.Dialogs.Any(dialog => !ReferenceEquals(dialog, _largeMapDialog));
        return new TravelMapHudSignals(
            HasUi: RuntimeContext.HasUi,
            IsMainPlayer: RuntimeContext.IsMainPlayer,
            IsRuntimeActive: _isActive,
            MiniMapSettingEnabled: _settings?.IsMiniMapVisible == true,
            HasModalSurface: hasModalSurface,
            IsLargeMapOpen: isLargeMapOpen,
            HasOtherPlayers: CountOtherPlayers() > 0,
            InvitationFeatureAvailable: TravelMapRuntimePolicy.CreatesInvitationUi(RuntimeContext),
            HasTextEntryFocus: !GetMapInputFocus().AllowsMapHotkey);
    }

    private void ApplyHudState(TravelMapHudState state)
    {
        var isPlacingMiniMap = _miniMapPlacementSession is not null;
        if (_miniMap is not null)
        {
            _miniMap.IsVisible = isPlacingMiniMap || state.ShowMiniMap;
            _miniMap.IsEnabled = !isPlacingMiniMap && state.AllowMiniMapInput;
        }

        if (_teleportPanelButton is not null)
        {
            _teleportPanelButton.IsVisible = !isPlacingMiniMap && state.ShowTeleportButton;
            _teleportPanelButton.IsEnabled = !isPlacingMiniMap
                && state.ShowTeleportButton
                && state.AllowMiniMapInput;
        }

        if (_openMapButton is not null)
        {
            _openMapButton.IsVisible = !isPlacingMiniMap && state.ShowOpenMapButton;
            _openMapButton.IsEnabled = !isPlacingMiniMap
                && state.ShowOpenMapButton
                && state.AllowOpenMapInput;
        }
    }

    /// <summary>
    /// Drops whatever touch the game's on-screen move/look pads have latched onto.
    /// <para>
    /// SurvivalCraft only suppresses those pads while a modal panel is up
    /// (<c>ComponentInput.UpdateInputFromWidgets</c> returns early on <c>ModalPanelWidget</c>);
    /// dialogs are expected to shield them by hit-testing on top, which works for a *new* touch but
    /// not for one already captured. <see cref="TouchInputWidget"/> only hit-tests on press, then
    /// follows that pointer id until it sees the matching release — so a finger resting on the move
    /// pad when the map opens keeps walking the player, and a release swallowed by any
    /// <c>Input.Clear()</c> leaves the pad latched onto a pointer id the platform later reuses, at
    /// which point dragging the map walks the player for the rest of the session.
    /// </para>
    /// Clearing the capture every frame the map owns the screen fixes both: no new capture is
    /// possible there anyway (the dialog covers the hit test), so there is nothing legitimate to
    /// lose. <c>m_touchInput</c> goes too, because the pads may already have updated this frame.
    /// </summary>
    private void ReleaseGameTouchCaptures()
    {
        var gui = Gui;
        if (gui is null)
        {
            return;
        }

        ReleaseTouchCapture(gui.MoveWidget);
        ReleaseTouchCapture(gui.LookWidget);
        ReleaseTouchCapture(gui.ViewWidget);
    }

    private static void ReleaseTouchCapture(TouchInputWidget? widget)
    {
        if (widget is null)
        {
            return;
        }

        widget.m_touchId = null;
        widget.m_touchInput = null;
    }

    private void BeginMiniMapPlacement()
    {
        if (_settings is null || _miniMap is null || _miniMapPlacementWidget is null)
        {
            return;
        }

        var guiSize = Player.GuiWidget.ActualSize;
        var positions = TravelMapOverlayLayout.PlaceHud(
            new Vector2(guiSize.X, guiSize.Y),
            _settings.MiniMapSize,
            _settings.MiniMapAnchorX,
            _settings.MiniMapAnchorY);
        _miniMapPlacementSession = new MiniMapPlacementSession(positions.MiniMap);
        if (_largeMapDialog is not null && DialogsManager.Dialogs.Contains(_largeMapDialog))
        {
            DialogsManager.HideDialog(_largeMapDialog);
        }

        DialogsManager.ShowDialog(Player.GuiWidget, _miniMapPlacementWidget);
        ApplyHudState(TravelMapHudPolicy.Evaluate(GetHudSignals()));
        UpdateHudPositions();
        Player.GameWidget.Input.Clear();
    }

    private void UpdateMiniMapPlacement()
    {
        var session = _miniMapPlacementSession;
        if (session is null || _settings is null)
        {
            return;
        }

        var input = Player.GameWidget.Input;
        if (input.Cancel)
        {
            CancelMiniMapPlacement();
            return;
        }

        Engine.Vector2? startPointer = null;
        if (input.IsMouseButtonDownOnce(MouseButton.Left) && input.MousePosition.HasValue)
        {
            startPointer = input.MousePosition;
        }
        else if (input.Tap.HasValue)
        {
            startPointer = input.Tap;
        }

        if (startPointer.HasValue)
        {
            var local = Player.GuiWidget.ScreenToWidget(startPointer.Value);
            session.TryBeginDrag(new Vector2(local.X, local.Y), _settings.MiniMapSize);
        }

        Engine.Vector2? activePointer = null;
        if (input.IsMouseButtonDown(MouseButton.Left) && input.MousePosition.HasValue)
        {
            activePointer = input.MousePosition;
        }
        else if (input.Press.HasValue)
        {
            activePointer = input.Press;
        }

        if (session.IsDragging && activePointer.HasValue)
        {
            var local = Player.GuiWidget.ScreenToWidget(activePointer.Value);
            var guiSize = Player.GuiWidget.ActualSize;
            session.DragTo(
                new Vector2(local.X, local.Y),
                new Vector2(guiSize.X, guiSize.Y),
                _settings.MiniMapSize);
            UpdateHudPositions();
            input.Clear();
        }
        else if (session.IsDragging)
        {
            session.EndDrag();
        }
    }

    private void ConfirmMiniMapPlacement()
    {
        if (_miniMapPlacementSession is null || _settings is null)
        {
            return;
        }

        var guiSize = Player.GuiWidget.ActualSize;
        var anchor = _miniMapPlacementSession.CreateNormalizedAnchor(
            new Vector2(guiSize.X, guiSize.Y),
            _settings.MiniMapSize);
        _settings.MiniMapAnchorX = anchor.X;
        _settings.MiniMapAnchorY = anchor.Y;
        _miniMapPlacementSession = null;
        if (_miniMapPlacementWidget is not null)
        {
            DialogsManager.HideDialog(_miniMapPlacementWidget);
        }

        UpdateHudPositions();
        ApplyHudState(TravelMapHudPolicy.Evaluate(GetHudSignals()));
        _miniMapPlacementSaveTask = PersistMiniMapPlacementAsync();
        ShowMessage(
            TravelMapText.Get("miniMapPositionSaved", "小地图位置已保存"),
            TravelMapNoticeKind.Success);
        Player.GameWidget.Input.Clear();
    }

    private void CancelMiniMapPlacement()
    {
        if (_miniMapPlacementSession is null)
        {
            return;
        }

        _miniMapPlacementSession.Cancel();
        _miniMapPlacementSession = null;
        if (_miniMapPlacementWidget is not null)
        {
            DialogsManager.HideDialog(_miniMapPlacementWidget);
        }

        UpdateHudPositions();
        ApplyHudState(TravelMapHudPolicy.Evaluate(GetHudSignals()));
        ShowMessage(
            TravelMapText.Get("miniMapPositionCancelled", "已取消调整小地图位置"),
            TravelMapNoticeKind.Information);
        Player.GameWidget.Input.Clear();
    }

    private async Task PersistMiniMapPlacementAsync()
    {
        try
        {
            if (_settingsStore is not null && _settings is not null)
            {
                await _settingsStore.SaveAsync(_settings, _lifetimeCancellation.Token)
                    .ConfigureAwait(false);
            }
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException)
        {
            ShowMessage(
                TravelMapText.Get(
                    "miniMapPositionSaveFailed",
                    "小地图位置未能保存，本次会话仍保留当前位置"),
                TravelMapNoticeKind.Failure);
        }
    }

    private int CountOtherPlayers() => Project
        .FindSubsystem<SubsystemPlayers>(true)
        .ComponentPlayers
        .Count(player => player.PlayerGuid != Player.PlayerGuid);

    private IReadOnlyList<LegacyTeleportPlayer> GetLegacyTeleportPlayers()
    {
        var players = Project.FindSubsystem<SubsystemPlayers>(true).ComponentPlayers;
        return players
            .Where(player => player.PlayerGuid != Player.PlayerGuid)
            .Select(player => new LegacyTeleportPlayer(player.PlayerGuid, player.PlayerData.Name))
            .OrderBy(player => player.Name, StringComparer.OrdinalIgnoreCase)
            .ToArray();
    }

    private void QueueLegacyPackage(LegacyGpsMessage message)
    {
        if (TravelMapRuntimePolicy.UsesAuthoritativeHostTeleport(RuntimeContext)
            && Project is ProjectNet projectNet)
        {
            TravelMapNetworkRuntime.HandleLegacyHost(message, Player, projectNet, CommonLib.Net);
            return;
        }

        if (!TravelMapStartup.IsLegacyGpsAvailable)
        {
            ShowMessage(
                TravelMapText.Get(
                    "networkPackageConflict",
                    "地图网络通道被其他模组占用（数据包ID冲突），联机传送暂不可用；地图其他功能不受影响"),
                TravelMapNoticeKind.Failure);
            return;
        }

        CommonLib.Net.QueuePackage(new LegacyGpsPackage(message));
    }

    private void UpdateExploration(float dt)
    {
        if (_explorationRecorder is null || _explorationCoverageProbe is null)
        {
            return;
        }

        var position = Player.ComponentBody.Position;
        _mapViewState?.UpdatePlayerY(position.Y);
        _storagePressureDiagnosticCooldown = MathF.Max(0f, _storagePressureDiagnosticCooldown - dt);
        if (_storagePressureBackoff > 0f)
        {
            // Saving is behind, so every attempt would be refused after paying for a full chunk
            // sample. Stand down until the flush has had time to drain instead of burning the
            // frame budget on work that is thrown away.
            _storagePressureBackoff -= dt;
            return;
        }

        var center = TerrainChunkCoordinate.FromWorld(
            checked((int)MathF.Floor(position.X)),
            checked((int)MathF.Floor(position.Z)));
        // Rescanning every loaded chunk (Distinct + sort + allocation) each frame is a heavy
        // per-frame cost on mobile, yet the set only changes when the player crosses a chunk
        // boundary or chunks stream in. Recompute + cache it on a chunk change or a short interval;
        // pending recordings still drain every frame so exploration is revealed just as promptly.
        if (_lastObservedCenter != center
            || _framesSinceExplorationObserve++ >= ExplorationObserveIntervalFrames)
        {
            _framesSinceExplorationObserve = 0;
            _lastObservedCenter = center;
            _cachedLoadedChunks = Terrain.Terrain.AllocatedChunks
                .Where(chunk => chunk is not null
                    && SurvivalcraftTerrainMapSource.IsSurfaceReadable(chunk.State))
                .Select(chunk => new TerrainChunkCoordinate(chunk.Coords.X, chunk.Coords.Y))
                .Distinct()
                .OrderBy(chunk => DistanceSquared(chunk, center))
                .ThenBy(chunk => chunk.X)
                .ThenBy(chunk => chunk.Z)
                .ToArray();
            _explorationScheduler.ObserveChunks(center, _cachedLoadedChunks);
        }

        _explorationScheduler.ReconcileCoverage(
            _explorationCoverageProbe.IsFullyExplored,
            MaximumCoverageChecksPerFrame);

        var pressured = false;
        foreach (var chunk in _explorationScheduler.GetPendingAttempts(MaximumChunkAttemptsPerFrame))
        {
            try
            {
                var result = _explorationRecorder.RecordChunk(chunk);
                if (result == ExplorationRecordResult.Recorded)
                {
                    _explorationScheduler.MarkCompleted(chunk);
                }
                else if (result == ExplorationRecordResult.Pressure)
                {
                    pressured = true;
                }
            }
            catch (Exception exception)
            {
                _explorationFailureReporter.Report(
                    chunk,
                    ExplorationFailureOperation.Record,
                    exception);
            }

            if (pressured)
            {
                break;
            }
        }

        if (pressured)
        {
            ReportStoragePressure(isCaveLayer: false);
            return;
        }

        UpdateCaveExploration(_cachedLoadedChunks);
    }

    private void UpdateCaveExploration(IReadOnlyList<TerrainChunkCoordinate> loadedChunks)
    {
        if (_caveSampler is null
            || _caveStore is null
            || _explorationRecorder is null
            || _mapViewState?.Mode != MapViewMode.Cave)
        {
            return;
        }

        var layerY = _mapViewState.CaveY;
        Span<Rgba32> colors = stackalloc Rgba32[TerrainChunkCoordinate.PixelCount];
        Span<byte> heightShades = stackalloc byte[TerrainChunkCoordinate.PixelCount];
        var attempts = 0;
        foreach (var chunk in loadedChunks)
        {
            if (attempts >= MaximumCaveChunkAttemptsPerFrame)
            {
                break;
            }

            if (!_explorationRecorder.IsChunkFullyExplored(chunk)
                || _caveStore.IsChunkFullyExplored(layerY, chunk))
            {
                continue;
            }

            // Cave sampling is the most expensive scan in the mod (a +/-8 block column probe per
            // pixel), so the admission check comes before it rather than after.
            if (!_caveStore.CanAdmit(layerY, chunk))
            {
                ReportStoragePressure(isCaveLayer: true);
                break;
            }

            attempts++;
            if (!_caveSampler.TrySampleChunk(chunk, layerY, colors, heightShades))
            {
                continue;
            }

            var result = _caveStore.RecordChunk(layerY, chunk, colors, heightShades);
            if (result == ExplorationRecordResult.Pressure)
            {
                ReportStoragePressure(isCaveLayer: true);
                break;
            }
        }
    }

    /// <summary>
    /// Saving has fallen behind exploration. Back off, warn the player once, and log enough state
    /// to tell a slow flush apart from a stuck one the next time this shows up in a bug report.
    /// </summary>
    private void ReportStoragePressure(bool isCaveLayer)
    {
        _storagePressureBackoff = StoragePressureBackoffSeconds;
        if (_storagePressureDiagnosticCooldown <= 0f)
        {
            _storagePressureDiagnosticCooldown = StoragePressureDiagnosticSeconds;
            Engine.Log.Warning(DescribeStoragePressure(isCaveLayer));
        }

        if (!_explorationPressureWarningShown)
        {
            _explorationPressureWarningShown = true;
            ShowMessage(
                TravelMapText.Get(
                    "mapStoragePaused",
                    "地图保存跟不上探索速度，已暂停记录新区块；已探索内容不会丢失，稍后自动继续"),
                TravelMapNoticeKind.Failure);
        }
    }

    private string DescribeStoragePressure(bool isCaveLayer)
    {
        var scope = isCaveLayer ? "cave" : "surface";
        var description = new StringBuilder("[TravelMap] Map storage backpressure: scope=")
            .Append(scope);
        if (isCaveLayer && _caveStore is not null && _mapViewState is not null)
        {
            var layerY = _mapViewState.CaveY;
            description
                .Append(", caveY=")
                .Append(layerY)
                .Append(", caveLayers=")
                .Append(_caveStore.LayerCount)
                .Append(", ")
                .Append(Describe(_caveStore.GetDiagnostics(layerY), CaveExplorationStore.LayerTileCapacity));
        }

        if (_tileStore is not null)
        {
            description
                .Append(", surface ")
                .Append(Describe(_tileStore.Diagnostics, _tileStore.Capacity));
        }

        return description.ToString();

        static string Describe(ExplorationTileStoreDiagnostics diagnostics, int capacity) =>
            $"cached={diagnostics.CachedTileCount}/{capacity}, dirty={diagnostics.DirtyTileCount}, "
            + $"known={diagnostics.KnownTileCount}, "
            + $"lastFlush={diagnostics.LastFlushTileCount} tiles/{diagnostics.LastFlushMilliseconds}ms";
    }

    private static long DistanceSquared(
        TerrainChunkCoordinate left,
        TerrainChunkCoordinate right)
    {
        var dx = (long)left.X - right.X;
        var dz = (long)left.Z - right.Z;
        return dx * dx + dz * dz;
    }

    private static void LogExplorationFailure(string message)
    {
        Engine.Log.Warning(message);
    }

    private void UpdateFlush(float dt)
    {
        if (_tileStore is null && _caveStore is null)
        {
            return;
        }

        if (_flushTask is { IsCompleted: true })
        {
            if (_flushTask.IsFaulted)
            {
                Engine.Log.Warning($"[TravelMap] Map flush failed: {_flushTask.Exception?.GetBaseException().Message}");
            }

            _flushTask = null;
        }

        _flushElapsed += MathF.Max(0f, dt);
        var flushInterval = _tileStore?.FlushInterval ?? _caveStore!.FlushInterval;
        if (_flushTask is null && _flushElapsed >= (float)flushInterval.TotalSeconds)
        {
            _flushElapsed = 0f;
            _flushTask = FlushMapStoresAsync(_lifetimeCancellation.Token);
        }
    }

    private async Task FlushMapStoresAsync(CancellationToken cancellationToken)
    {
        if (_tileStore is not null)
        {
            await _tileStore.FlushAsync(cancellationToken).ConfigureAwait(false);
        }

        if (_caveStore is not null)
        {
            await _caveStore.FlushAsync(cancellationToken).ConfigureAwait(false);
        }
    }

    private void HandleLargeMapHotkey()
    {
        if (_largeMapDialog is null)
        {
            return;
        }

        var input = Player.GameWidget.Input;
        var isOpen = DialogsManager.Dialogs.Contains(_largeMapDialog);
        var focus = GetMapInputFocus(ignoreLargeMapDialog: isOpen);
        var command = _uiController.HandleToggleHotkey(
            input.IsKeyDownOnce(Engine.Input.Key.M),
            isOpen,
            focus);
        if (command.Kind == TravelMapUiCommandKind.OpenLargeMap)
        {
            OpenLargeMap();
        }
        else if (command.Kind == TravelMapUiCommandKind.CloseLargeMap)
        {
            DialogsManager.HideDialog(_largeMapDialog);
            input.Clear();
        }
    }

    private void OpenLargeMap()
    {
        if (_largeMapDialog is null || !GetMapInputFocus().AllowsMapHotkey)
        {
            return;
        }

        _largeMapDialog.ResetToPlayer();
        DialogsManager.ShowDialog(Player.GuiWidget, _largeMapDialog);
        ApplyHudState(TravelMapHudPolicy.Evaluate(GetHudSignals()));
        Player.GameWidget.Input.Clear();
    }

    private void OpenLargeMapAtLastDeath(DeathMapMarker marker)
    {
        if (_largeMapDialog is null || !GetMapInputFocus().AllowsMapHotkey)
        {
            return;
        }

        _largeMapDialog.ResetToWorld(new Vector2(marker.Position.X, marker.Position.Z));
        DialogsManager.ShowDialog(Player.GuiWidget, _largeMapDialog);
        ApplyHudState(TravelMapHudPolicy.Evaluate(GetHudSignals()));
        Player.GameWidget.Input.Clear();
    }

    private TravelMapFocusState GetMapInputFocus(bool ignoreLargeMapDialog = false)
    {
        var chat = Player.GameWidget.messageWidget;
        var hasDialogs = ignoreLargeMapDialog && _largeMapDialog is not null
            ? DialogsManager.Dialogs.Any(dialog => !ReferenceEquals(dialog, _largeMapDialog))
            : DialogsManager.HasDialogs(Player.GuiWidget);
        return TravelMapInputFocusEvaluator.Evaluate(new TravelMapInputFocusSignals(
            HasFocusedTextBox(Player.GuiWidget),
            chat?.IsVisible == true,
            chat?.EditText?.HasFocus == true,
            Gui?.ModalPanelWidget is not null || hasDialogs));
    }

    private bool IsMapInputBlocked() => !GetMapInputFocus().AllowsMapHotkey;

    private async Task<TravelMapActionStatus> HandleContextActionAsync(
        TravelMapContextAction action,
        TravelMapContextMenu menu,
        CancellationToken cancellationToken)
    {
        if (_waypointRepository is null)
        {
            return TravelMapActionStatus.Failed;
        }

        switch (action)
        {
            case TravelMapContextAction.TeleportNearby:
            {
                var target = new Vector3(
                    menu.WorldPosition.X,
                    menu.TargetY ?? Player.ComponentBody.Position.Y,
                    menu.WorldPosition.Y);
                return menu.TargetY.HasValue
                    ? await RequestWaypointTravelAsync(target, cancellationToken).ConfigureAwait(false)
                    : await RequestSurfaceTravelAsync(target, cancellationToken).ConfigureAwait(false);
            }
            case TravelMapContextAction.TeleportToWaypoint:
            {
                var waypoint = FindWaypoint(menu.WaypointId);
                return waypoint is null
                    ? TravelMapActionStatus.Failed
                    : await RequestWaypointTravelAsync(waypoint.Position, cancellationToken).ConfigureAwait(false);
            }
            case TravelMapContextAction.TeleportToLastDeath:
            {
                var lastDeath = GetLastDeathMarker();
                if (lastDeath is null)
                {
                    ShowMessage(
                        TravelMapText.Get("lastDeathUnavailable", "还没有可返回的死亡地点"),
                        TravelMapNoticeKind.Information);
                    return TravelMapActionStatus.FailedWithFeedback;
                }

                return await RequestWaypointTravelAsync(lastDeath.Position, cancellationToken)
                    .ConfigureAwait(false);
            }
            case TravelMapContextAction.DeleteLastDeath:
            {
                var identity = LatestDeathIdentity(Player.PlayerStats);
                if (identity is null || GetLastDeathMarker() is null)
                {
                    ShowMessage(
                        TravelMapText.Get("lastDeathUnavailable", "还没有可返回的死亡地点"),
                        TravelMapNoticeKind.Information);
                    return TravelMapActionStatus.FailedWithFeedback;
                }

                _dismissedDeaths.Add(identity.Value);
                await SaveDismissedDeathAsync(identity.Value, cancellationToken).ConfigureAwait(false);
                return TravelMapActionStatus.Completed;
            }
            case TravelMapContextAction.TeleportToPreviousDeath:
            {
                var previousDeath = GetPreviousDeathMarker();
                if (previousDeath is null)
                {
                    ShowMessage(
                        TravelMapText.Get("lastDeathUnavailable", "还没有可返回的死亡地点"),
                        TravelMapNoticeKind.Information);
                    return TravelMapActionStatus.FailedWithFeedback;
                }

                return await RequestWaypointTravelAsync(previousDeath.Position, cancellationToken)
                    .ConfigureAwait(false);
            }
            case TravelMapContextAction.DeletePreviousDeath:
            {
                var identity = PreviousDeathIdentity(Player.PlayerStats);
                if (identity is null || GetPreviousDeathMarker() is null)
                {
                    ShowMessage(
                        TravelMapText.Get("lastDeathUnavailable", "还没有可返回的死亡地点"),
                        TravelMapNoticeKind.Information);
                    return TravelMapActionStatus.FailedWithFeedback;
                }

                _dismissedDeaths.Add(identity.Value);
                await SaveDismissedDeathAsync(identity.Value, cancellationToken).ConfigureAwait(false);
                return TravelMapActionStatus.Completed;
            }
            case TravelMapContextAction.AddWaypoint:
            {
                // Save the point the player tapped on the map (X/Z), not the player's own position.
                // A top-down tap has no height, so derive Y from the surface at that column; the
                // cave view supplies its own Y through TargetY.
                var wx = menu.WorldPosition.X;
                var wz = menu.WorldPosition.Y;
                var y = menu.TargetY.HasValue
                    ? (int)MathF.Round(menu.TargetY.Value)
                    : TryGetSurfaceHeight((int)MathF.Floor(wx), (int)MathF.Floor(wz), out var surface)
                        ? surface
                        // Column not loaded (tapped far from the player): keep the marker on the
                        // tapped spot with the player's height; teleport surface-searches from there.
                        : (int)MathF.Round(Player.ComponentBody.Position.Y);
                var position = new Vector3(wx, y, wz);
                _waypointRepository.Add(
                    TravelMapText.Format(
                        "mapPointWaypointFormat",
                        "坐标点 {0:0.##}, {1:0.##}, {2:0.##}",
                        position.X,
                        position.Y,
                        position.Z),
                    position);
                _waypoints = await WaypointPersistence.SaveOrReloadAsync(
                    _waypointRepository,
                    cancellationToken).ConfigureAwait(false);
                ShowMessage(
                    TravelMapText.Get("waypointSaved", "坐标点已保存"),
                    TravelMapNoticeKind.Success);
                return TravelMapActionStatus.Completed;
            }
            case TravelMapContextAction.AddPlayerWaypoint:
            {
                if (_currentPositionWaypointHandler is null)
                {
                    return TravelMapActionStatus.Failed;
                }

                _waypoints = await _currentPositionWaypointHandler.SaveAsync(cancellationToken)
                    .ConfigureAwait(false);
                ShowMessage(
                    TravelMapText.Get("waypointSaved", "坐标点已保存"),
                    TravelMapNoticeKind.Success);
                return TravelMapActionStatus.Completed;
            }
            case TravelMapContextAction.RenameWaypoint:
            {
                var waypoint = FindWaypoint(menu.WaypointId);
                if (waypoint is null)
                {
                    return TravelMapActionStatus.Failed;
                }

                DialogsManager.Promit(
                    TravelMapText.Get("renameWaypoint", "重命名坐标点"),
                    waypoint.Name,
                    name => _uiActions?.TryRun(_ => RenameWaypointAsync(waypoint.Id, name)));
                return TravelMapActionStatus.Completed;
            }
            case TravelMapContextAction.DeleteWaypoint:
                if (!menu.WaypointId.HasValue || !_waypointRepository.Remove(menu.WaypointId.Value))
                {
                    return TravelMapActionStatus.Failed;
                }

                await SaveWaypointsAsync(cancellationToken).ConfigureAwait(false);
                ShowMessage(
                    TravelMapText.Get("waypointDeleted", "坐标点已删除"),
                    TravelMapNoticeKind.Success);
                return TravelMapActionStatus.Completed;
            case TravelMapContextAction.Cancel:
                return TravelMapActionStatus.Cancelled;
            default:
                throw new ArgumentOutOfRangeException(nameof(action));
        }
    }

    private async Task<TravelMapActionStatus> RequestSurfaceTravelAsync(
        Vector3 target,
        CancellationToken cancellationToken)
    {
        var router = new TravelMapTeleportRouter(
            RuntimeContext,
            async (position, token) =>
            {
                var result = await TeleportToSurfaceAsync(
                    checked((int)MathF.Floor(position.X)),
                    checked((int)MathF.Floor(position.Z)),
                    token).ConfigureAwait(false);
                return result == TeleportResult.Success
                    ? TravelMapTeleportDispatchResult.LocalRequested
                    : TravelMapTeleportDispatchResult.LocalFailed;
            },
            RequestAuthoritativeHostTravelAsync,
            ClientTravelCommand);
        return ToActionStatus(await router.RequestSurfaceAsync(target, cancellationToken).ConfigureAwait(false));
    }

    private async Task<TravelMapActionStatus> RequestWaypointTravelAsync(
        Vector3 target,
        CancellationToken cancellationToken)
    {
        var router = new TravelMapTeleportRouter(
            RuntimeContext,
            async (position, token) =>
            {
                var result = await TeleportToWaypointAsync(position, token).ConfigureAwait(false);
                return result == TeleportResult.Success
                    ? TravelMapTeleportDispatchResult.LocalRequested
                    : TravelMapTeleportDispatchResult.LocalFailed;
            },
            RequestAuthoritativeHostTravelAsync,
            ClientTravelCommand);
        return ToActionStatus(await router.RequestWaypointAsync(target, cancellationToken).ConfigureAwait(false));
    }

    private async Task<TravelMapTeleportDispatchResult> RequestAuthoritativeHostTravelAsync(
        TravelMapClientTravelCommand command,
        CancellationToken cancellationToken)
    {
        var host = _authoritativeHostTeleport;
        if (!TravelMapRuntimePolicy.UsesAuthoritativeHostTeleport(RuntimeContext) || host is null)
        {
            return TravelMapTeleportDispatchResult.Unavailable;
        }

        var result = command.Mode == TravelMapClientTravelMode.Surface
            ? await host.RequestSurfaceAsync(
                checked((int)MathF.Floor(command.Target.X)),
                checked((int)MathF.Floor(command.Target.Z)),
                cancellationToken).ConfigureAwait(false)
            : await host.RequestWaypointAsync(command.Target, cancellationToken).ConfigureAwait(false);
        ShowMessage(TravelMapNoticeFactory.For(result));
        return result == CoordinateTeleportResultCode.Success
            ? TravelMapTeleportDispatchResult.LocalRequested
            : TravelMapTeleportDispatchResult.LocalFailed;
    }

    private Waypoint? FindWaypoint(Guid? id) => id.HasValue
        ? _waypoints.FirstOrDefault(waypoint => waypoint.Id == id.Value)
        : null;

    // Reads the topmost solid height at a column via the map source, which only succeeds when the
    // chunk is loaded and its surface is ready; far-away tapped columns aren't loaded, so the caller
    // falls back.
    private bool TryGetSurfaceHeight(int x, int z, out int height)
    {
        if (_terrainMapSource is not null && _terrainMapSource.TryGetSolidHeight(x, z, out height))
        {
            return true;
        }

        height = 0;
        return false;
    }

    private async Task RenameWaypointAsync(Guid id, string name)
    {
        try
        {
            if (_waypointRepository is not null && _waypointRepository.Rename(id, name))
            {
                await SaveWaypointsAsync(_lifetimeCancellation.Token).ConfigureAwait(false);
                ShowMessage(
                    TravelMapText.Get("waypointRenamed", "坐标点已重命名"),
                    TravelMapNoticeKind.Success);
            }
        }
        catch (Exception exception) when (exception is ArgumentException or IOException)
        {
            ShowMessage(
                TravelMapText.Get("waypointRenameFailed", "坐标点名称未保存"),
                TravelMapNoticeKind.Failure);
        }
    }

    private async Task SaveWaypointsAsync(CancellationToken cancellationToken)
    {
        try
        {
            _waypoints = await WaypointPersistence.SaveOrReloadAsync(
                _waypointRepository!,
                cancellationToken).ConfigureAwait(false);
        }
        catch
        {
            _waypoints = _waypointRepository!.GetAll();
            throw;
        }
    }

    private async Task SaveDismissedDeathAsync(
        DeathMarkerIdentity identity,
        CancellationToken cancellationToken)
    {
        if (_dismissedDeathStore is null)
        {
            return;
        }

        await _dismissedDeathStore.AddAsync(identity, cancellationToken).ConfigureAwait(false);
    }

    private PlayerMapPose GetPlayerPose()
    {
        var position = Player.ComponentBody.Position;
        var forward = Player.ComponentBody.Matrix.Forward;
        // The map plane is rotated 180 degrees from raw world coordinates so the minimap matches
        // the in-game sun (see MapTransform). The player arrow/heading must be rotated the same
        // 180 degrees, i.e. Atan2(forward.X, -forward.Z) + PI, written here in its reduced form.
        return new PlayerMapPose(
            new Vector3(position.X, position.Y, position.Z),
            MathF.Atan2(-forward.X, forward.Z));
    }

    private DeathMapMarker? GetLastDeathMarker() =>
        SelectCurrentDeath(Player.PlayerStats, _dismissedDeaths);

    private DeathMapMarker? GetPreviousDeathMarker() =>
        SelectPreviousDeath(Player.PlayerStats, _dismissedDeaths);

    /// <summary>
    /// The tracked "current" death: the newest record unless the player dismissed exactly that
    /// record. A later death (a newer record) is a distinct identity and re-shows a marker.
    /// </summary>
    internal static DeathMapMarker? SelectCurrentDeath(
        PlayerStats? stats,
        IReadOnlySet<DeathMarkerIdentity>? dismissedDeaths)
    {
        if (stats is null)
        {
            return null;
        }

        var records = stats.DeathRecords;
        if (records.Count == 0)
        {
            return null;
        }

        var record = records[records.Count - 1];
        if (dismissedDeaths is not null && dismissedDeaths.Contains(IdentityOf(record)))
        {
            return null;
        }

        return ToMarker(record);
    }

    /// <summary>
    /// The "previous" death: the second-to-last record, shown regardless of whether the current
    /// death was dismissed, unless the player individually dismissed this previous record too.
    /// </summary>
    internal static DeathMapMarker? SelectPreviousDeath(
        PlayerStats? stats,
        IReadOnlySet<DeathMarkerIdentity>? dismissedDeaths)
    {
        if (stats is null)
        {
            return null;
        }

        var records = stats.DeathRecords;
        if (records.Count < 2)
        {
            return null;
        }

        var record = records[records.Count - 2];
        if (dismissedDeaths is not null && dismissedDeaths.Contains(IdentityOf(record)))
        {
            return null;
        }

        return ToMarker(record);
    }

    /// <summary>Identity of the newest death record, used when dismissing the current death.</summary>
    internal static DeathMarkerIdentity? LatestDeathIdentity(PlayerStats? stats)
    {
        if (stats is null)
        {
            return null;
        }

        var records = stats.DeathRecords;
        return records.Count == 0 ? null : IdentityOf(records[records.Count - 1]);
    }

    /// <summary>Identity of the second-to-last death record, used when dismissing the previous death.</summary>
    internal static DeathMarkerIdentity? PreviousDeathIdentity(PlayerStats? stats)
    {
        if (stats is null)
        {
            return null;
        }

        var records = stats.DeathRecords;
        return records.Count < 2 ? null : IdentityOf(records[records.Count - 2]);
    }

    private static DeathMarkerIdentity IdentityOf(PlayerStats.DeathRecord record) =>
        DeathMarkerIdentity.FromLocation(
            record.Day,
            new Vector3(record.Location.X, record.Location.Y, record.Location.Z));

    private static DeathMapMarker? ToMarker(PlayerStats.DeathRecord record)
    {
        var position = new Vector3(record.Location.X, record.Location.Y, record.Location.Z);
        return float.IsFinite(position.X)
            && float.IsFinite(position.Y)
            && float.IsFinite(position.Z)
                ? new DeathMapMarker(position, record.Day, record.Cause ?? string.Empty)
                : null;
    }

    private IReadOnlyList<CreatureMapMarker> GetCreatureMarkers()
    {
        if (CreatureSpawn is null)
        {
            return [];
        }

        var markers = new List<CreatureMapMarker>();
        foreach (var creature in CreatureSpawn.Creatures)
        {
            if (ReferenceEquals(creature, Player)
                || creature.ComponentBody is null
                || creature.ComponentHealth is { Health: <= 0f })
            {
                continue;
            }

            var position = creature.ComponentBody.Position;
            if (_mapViewState is { Mode: MapViewMode.Cave } caveView
                && MathF.Abs(position.Y - caveView.CaveY) > CaveLayer.MarkerVerticalRange)
            {
                continue;
            }

            markers.Add(new CreatureMapMarker(
                new Vector3(position.X, position.Y, position.Z),
                ToCreatureMarkerKind(creature.Category)));
        }

        return markers;
    }

    private IReadOnlyList<Waypoint> GetVisibleWaypoints() =>
        _mapViewState is { Mode: MapViewMode.Cave } caveView
            ? _waypoints
                .Where(waypoint => MathF.Abs(waypoint.Position.Y - caveView.CaveY)
                    <= CaveLayer.MarkerVerticalRange)
                .ToArray()
            : _waypoints;

    internal static CreatureMapMarkerKind ToCreatureMarkerKind(CreatureCategory category)
    {
        if ((category & (CreatureCategory.LandPredator | CreatureCategory.WaterPredator)) != 0)
        {
            return CreatureMapMarkerKind.Predator;
        }

        return (category & CreatureCategory.Bird) != 0
            ? CreatureMapMarkerKind.Bird
            : CreatureMapMarkerKind.Other;
    }

    private float GetTerrainBrightness() => _settings is { UseDayNightTint: true }
        ? DayNightBrightness.Calculate(TimeOfDay.TimeOfDay, _settings.NightMinimumBrightness)
        : 1f;

    private float GetMapBrightness() => _mapViewState?.Mode == MapViewMode.Cave
        ? 1f
        : GetTerrainBrightness();

    private float GetGameTime() => TimeOfDay.TimeOfDay;

    private void ShowMessage(TravelMapNotice notice)
    {
        ShowMessage(notice.Text, notice.Kind);
    }

    private void ShowMessage(
        string message,
        TravelMapNoticeKind kind = TravelMapNoticeKind.Information)
    {
        try
        {
            _dispatcher?.Invoke(() =>
            {
                if (_largeMapDialog is not null
                    && DialogsManager.Dialogs.Contains(_largeMapDialog))
                {
                    _largeMapDialog.ShowNotice(new TravelMapNotice(message, kind));
                    return;
                }

                Gui?.DisplaySmallMessage(
                    message,
                    Engine.Color.White,
                    blinking: false,
                    playNotificationSound: false);
            });
        }
        catch (ObjectDisposedException)
        {
        }
    }

    private void WarnPersistenceOnce(string message)
    {
        if (_persistenceWarningShown)
        {
            return;
        }

        _persistenceWarningShown = true;
        Engine.Log.Warning($"[TravelMap] {message}");
        ShowMessage(message, TravelMapNoticeKind.Failure);
    }

    private void CleanupRuntimeResources()
    {
        _isActive = false;
        _explorationScheduler.Clear();
        _explorationFailureReporter.Clear();
        // Before anything is cancelled: the component is torn down and rebuilt on every respawn
        // (the game creates a fresh player entity each time), so whatever is still dirty here is
        // explored map that would otherwise be dropped on the floor.
        RunCleanupStep(FlushMapStoresBeforeShutdown);
        RunCleanupStep(() => _lifetimeCancellation.Cancel());
        RunCleanupStep(() =>
        {
            lock (_networkSync)
            {
                _coordinateServerSession?.Dispose();
                _coordinateServerSession = null;
                _authoritativeHostTeleport?.Dispose();
                _authoritativeHostTeleport = null;
                _coordinateClientSession?.Dispose();
                _coordinateClientSession = null;
            }
        });
        RunCleanupStep(() => _chunkLoader?.Dispose());
        RunCleanupStep(CleanupUi);
        RunCleanupStep(() => _dispatcher?.Dispose());
        _chunkLoader = null;
        _dispatcher = null;
        TeleportService = null;
        ClientTravelCommand = null;
        _settingsStore = null;
        _settings = null;
        _tileStore = null;
        _caveStore = null;
        _explorationRecorder = null;
        _caveSampler = null;
        _explorationCoverageProbe = null;
        _mapViewState = null;
        _waypointRepository = null;
        _currentPositionWaypointHandler = null;
        _waypoints = Array.Empty<Waypoint>();
        _flushTask = null;
        RunCleanupStep(() => _lifetimeCancellation.Dispose());
    }

    /// <summary>
    /// Drains the map stores while the component still owns them. The budget scales with the
    /// backlog so an ordinary teardown stays imperceptible while a real backlog gets a fair chance
    /// to reach disk, and anything left over is reported instead of vanishing silently.
    /// </summary>
    private void FlushMapStoresBeforeShutdown()
    {
        if (_tileStore is null && _caveStore is null)
        {
            return;
        }

        var backlog = (_tileStore?.Diagnostics.DirtyTileCount ?? 0)
            + (_caveStore?.TotalDirtyTileCount ?? 0);
        if (backlog == 0 && _flushTask is null)
        {
            return;
        }

        var budget = ShutdownFlushBudget(backlog);
        var clock = System.Diagnostics.Stopwatch.StartNew();
        TimeSpan Remaining() => clock.Elapsed >= budget ? TimeSpan.Zero : budget - clock.Elapsed;
        static void ReportFlushFailure(Exception exception) =>
            Engine.Log.Warning($"[TravelMap] Shutdown flush failed: {exception.Message}");

        // The in-flight cycle is already part-way through the same backlog, so it is waited on
        // rather than cancelled and redone.
        var inFlight = _flushTask;
        _flushTask = null;
        if (inFlight is not null)
        {
            RunCleanupStep(() => BoundedTaskObserver.ObserveWithin(
                inFlight,
                Remaining(),
                ReportFlushFailure));
        }

        if (Remaining() > TimeSpan.Zero)
        {
            RunCleanupStep(() =>
            {
                using var flushCancellation = new CancellationTokenSource(Remaining());
                BoundedTaskObserver.ObserveWithin(
                    FlushMapStoresAsync(flushCancellation.Token),
                    Remaining(),
                    ReportFlushFailure);
            });
        }

        var remainingTiles = (_tileStore?.Diagnostics.DirtyTileCount ?? 0)
            + (_caveStore?.TotalDirtyTileCount ?? 0);
        if (remainingTiles > 0)
        {
            Engine.Log.Warning(
                $"[TravelMap] Shutdown flush incomplete: {remainingTiles} of {backlog} tiles "
                + $"could not be written within {budget.TotalMilliseconds:F0}ms and were lost.");
        }
    }

    private static TimeSpan ShutdownFlushBudget(int backlog) => TimeSpan.FromMilliseconds(
        Math.Clamp(250d + (25d * backlog), 250d, 5000d));

    private static void RunCleanupStep(Action cleanup)
    {
        try
        {
            cleanup();
        }
        catch (Exception exception)
        {
            Engine.Log.Warning($"[TravelMap] Cleanup step failed: {exception.Message}");
        }
    }

    private void CleanupUi()
    {
        var networkActions = _networkActions;
        _networkActions = null;
        var uiActions = _uiActions;
        _uiActions = null;
        RunCleanupStep(() => networkActions?.Dispose());
        RunCleanupStep(() => uiActions?.Dispose());
        var shutdownClock = System.Diagnostics.Stopwatch.StartNew();
        var shutdownLimit = TimeSpan.FromSeconds(2);
        TimeSpan RemainingTime() => shutdownClock.Elapsed >= shutdownLimit
            ? TimeSpan.Zero
            : shutdownLimit - shutdownClock.Elapsed;
        static void ReportShutdownFailure(Exception exception) =>
            Engine.Log.Warning($"[TravelMap] Shutdown operation failed: {exception.Message}");
        Task? dialogWork = null;
        Task? miniMapWork = null;
        var placementSaveWork = _miniMapPlacementSaveTask;
        _miniMapPlacementSaveTask = null;
        _miniMapPlacementSession = null;
        if (_largeMapDialog is not null)
        {
            var largeMapDialog = _largeMapDialog;
            _largeMapDialog = null;
            RunCleanupStep(() => dialogWork = largeMapDialog.WhenBackgroundWorkIdleAsync());
            RunCleanupStep(() => DialogsManager.HideDialog(largeMapDialog));
            RunCleanupStep(largeMapDialog.Dispose);
        }

        if (_miniMap is not null)
        {
            var miniMap = _miniMap;
            _miniMap = null;
            RunCleanupStep(() => miniMapWork = miniMap.WhenSaveIdleAsync());
            RunCleanupStep(() => miniMap.ParentWidget?.Children.Remove(miniMap));
            RunCleanupStep(miniMap.Dispose);
        }

        if (_miniMapPlacementWidget is not null)
        {
            var placementWidget = _miniMapPlacementWidget;
            _miniMapPlacementWidget = null;
            RunCleanupStep(() => DialogsManager.HideDialog(placementWidget));
            RunCleanupStep(placementWidget.Dispose);
        }

        if (_teleportPanel is not null)
        {
            var teleportPanel = _teleportPanel;
            _teleportPanel = null;
            RunCleanupStep(() => DialogsManager.HideDialog(teleportPanel));
            RunCleanupStep(teleportPanel.Dispose);
        }

        if (_teleportPanelButton is not null)
        {
            var teleportPanelButton = _teleportPanelButton;
            _teleportPanelButton = null;
            RunCleanupStep(() => teleportPanelButton.ParentWidget?.Children.Remove(teleportPanelButton));
            RunCleanupStep(teleportPanelButton.Dispose);
        }

        if (_openMapButton is not null)
        {
            var openMapButton = _openMapButton;
            _openMapButton = null;
            RunCleanupStep(() => openMapButton.ParentWidget?.Children.Remove(openMapButton));
            RunCleanupStep(openMapButton.Dispose);
        }

        if (_teleportButtonTexture is not null)
        {
            var teleportButtonTexture = _teleportButtonTexture;
            _teleportButtonTexture = null;
            RunCleanupStep(teleportButtonTexture.Dispose);
        }

        if (_teleportButtonPressedTexture is not null)
        {
            var teleportButtonPressedTexture = _teleportButtonPressedTexture;
            _teleportButtonPressedTexture = null;
            RunCleanupStep(teleportButtonPressedTexture.Dispose);
        }

        // Map stores are drained by FlushMapStoresBeforeShutdown, ahead of cancellation and on its
        // own backlog-sized budget; the 2s budget here is for UI work only.
        if (dialogWork is not null && RemainingTime() > TimeSpan.Zero)
        {
            RunCleanupStep(() => BoundedTaskObserver.ObserveWithin(
                    dialogWork,
                    RemainingTime(),
                    ReportShutdownFailure));
        }


        if (miniMapWork is not null && RemainingTime() > TimeSpan.Zero)
        {
            RunCleanupStep(() => BoundedTaskObserver.ObserveWithin(
                    miniMapWork,
                    RemainingTime(),
                    ReportShutdownFailure));
        }

        if (placementSaveWork is not null && RemainingTime() > TimeSpan.Zero)
        {
            RunCleanupStep(() => BoundedTaskObserver.ObserveWithin(
                    placementSaveWork,
                    RemainingTime(),
                    ReportShutdownFailure));
        }

        if (_settingsStore is not null
            && _settings is not null
            && RemainingTime() > TimeSpan.Zero)
        {
            RunCleanupStep(() =>
            {
                using var settingsCancellation = new CancellationTokenSource(RemainingTime());
                BoundedTaskObserver.ObserveWithin(
                    _settingsStore.SaveAsync(_settings, settingsCancellation.Token),
                    RemainingTime(),
                    ReportShutdownFailure);
            });
        }

        if (uiActions is not null && RemainingTime() > TimeSpan.Zero)
        {
            RunCleanupStep(() => BoundedTaskObserver.ObserveWithin(
                    uiActions.WhenIdleAsync(),
                    RemainingTime(),
                    ReportShutdownFailure));
        }

        if (networkActions is not null && RemainingTime() > TimeSpan.Zero)
        {
            RunCleanupStep(() => BoundedTaskObserver.ObserveWithin(
                    networkActions.WhenIdleAsync(),
                    RemainingTime(),
                    ReportShutdownFailure));
        }
    }

    private static bool HasFocusedTextBox(Widget widget)
    {
        if (widget is TextBoxWidget { HasFocus: true })
        {
            return true;
        }

        if (widget is ContainerWidget container)
        {
            foreach (var child in container.Children)
            {
                if (HasFocusedTextBox(child))
                {
                    return true;
                }
            }
        }

        return false;
    }

    private static TravelMapActionStatus ToActionStatus(TravelMapTeleportDispatchResult result) => result switch
    {
        TravelMapTeleportDispatchResult.LocalRequested => TravelMapActionStatus.Completed,
        TravelMapTeleportDispatchResult.CommandQueued => TravelMapActionStatus.Completed,
        TravelMapTeleportDispatchResult.LocalFailed => TravelMapActionStatus.FailedWithFeedback,
        TravelMapTeleportDispatchResult.Unavailable => TravelMapActionStatus.Unavailable,
        _ => TravelMapActionStatus.Failed,
    };

    private sealed class UiInitializationState
    {
        internal string AppRoot { get; set; } = string.Empty;

        internal IExploredMapPixelSource? PixelSource { get; set; }

        internal WaypointLoadOutcome WaypointLoadOutcome { get; set; }
    }
}
