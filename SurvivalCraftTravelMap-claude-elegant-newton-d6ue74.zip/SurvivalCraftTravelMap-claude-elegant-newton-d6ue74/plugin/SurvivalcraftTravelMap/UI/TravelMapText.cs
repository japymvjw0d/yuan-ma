using Game;
using SurvivalcraftTravelMap.Settings;
using System.Globalization;

namespace SurvivalcraftTravelMap.UI;

internal static class TravelMapText
{
    public static string Get(string key, string fallback)
    {
        var text = LanguageControl.Get(out var found, "TravelMap", key);
        return found ? text : fallback;
    }

    public static string Format(string key, string fallback, params object?[] arguments) =>
        string.Format(CultureInfo.CurrentCulture, Get(key, fallback), arguments);

    public static string CompassDirection(CompassDirection direction) => direction switch
    {
        global::SurvivalcraftTravelMap.UI.CompassDirection.North => Get("compassNorth", "北"),
        global::SurvivalcraftTravelMap.UI.CompassDirection.East => Get("compassEast", "东"),
        global::SurvivalcraftTravelMap.UI.CompassDirection.South => Get("compassSouth", "南"),
        global::SurvivalcraftTravelMap.UI.CompassDirection.West => Get("compassWest", "西"),
        _ => string.Empty,
    };

    public static string MapShape(MapShape shape) => shape switch
    {
        global::SurvivalcraftTravelMap.Settings.MapShape.Circle => Get("mapShapeCircle", "圆形"),
        global::SurvivalcraftTravelMap.Settings.MapShape.Square => Get("mapShapeSquare", "方形"),
        global::SurvivalcraftTravelMap.Settings.MapShape.RoundedSquare => Get("mapShapeRoundedSquare", "圆角方形"),
        _ => string.Empty,
    };

    public static string LargeMapDetail(LargeMapDetail detail) => detail switch
    {
        global::SurvivalcraftTravelMap.Settings.LargeMapDetail.PowerSaver =>
            Get("largeMapDetailPowerSaver", "省内存"),
        global::SurvivalcraftTravelMap.Settings.LargeMapDetail.Standard =>
            Get("largeMapDetailStandard", "标准"),
        global::SurvivalcraftTravelMap.Settings.LargeMapDetail.High =>
            Get("largeMapDetailHigh", "高清"),
        _ => string.Empty,
    };

    public static string HeightShading(HeightShadingStyle style) => style switch
    {
        HeightShadingStyle.Off => Get("heightShadingOff", "关闭"),
        HeightShadingStyle.Soft => Get("heightShadingSoft", "柔和"),
        HeightShadingStyle.Standard => Get("heightShadingStandard", "标准"),
        HeightShadingStyle.HighContrast => Get("heightShadingHighContrast", "高对比"),
        _ => string.Empty,
    };
}
