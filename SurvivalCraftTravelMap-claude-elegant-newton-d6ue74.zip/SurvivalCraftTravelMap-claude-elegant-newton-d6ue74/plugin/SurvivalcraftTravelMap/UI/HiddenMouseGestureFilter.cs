namespace SurvivalcraftTravelMap.UI;

/// <summary>
/// Tells whether this frame's engine-computed Tap/Click gesture came from a hidden mouse.
/// </summary>
/// <remarks>
/// The game's WidgetInput derives Tap and Click from the mouse as well as from touch, and a
/// hidden in-game cursor keeps its last UI position. Attack clicks therefore produce Tap/Click
/// gestures at that stale position, which ClickableWidget-style hit tests treat as a click on
/// whatever HUD widget sits there. Touch gestures press no mouse button, so a hidden cursor
/// plus mouse button activity this frame or the previous one (Click fires on release, after
/// the button is already up) identifies a combat click rather than a real tap.
/// Call <see cref="Update"/> exactly once per frame so the release frame is recognized.
/// </remarks>
internal sealed class HiddenMouseGestureFilter
{
    private bool _mouseButtonActiveLastFrame;

    public bool Update(bool isMouseCursorVisible, bool mouseButtonPressedOnce, bool mouseButtonHeld)
    {
        var mouseActiveThisFrame = mouseButtonPressedOnce || mouseButtonHeld;
        var mouseActive = mouseActiveThisFrame || _mouseButtonActiveLastFrame;
        _mouseButtonActiveLastFrame = mouseActiveThisFrame;
        return !isMouseCursorVisible && mouseActive;
    }
}
